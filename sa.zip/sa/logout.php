<?php 
	include_once "session.php";
	$time=time();
	Logoutadmin($db);
	session_destroy();
	header("Location:".admin_public_url."index.php?err=lo");
	setcookie("admin","",0,"/");
	exit;
?>