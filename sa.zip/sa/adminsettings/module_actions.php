<?php 
require_once '../session.php';
extract($_REQUEST);
$act=$action;

if($chkstatus !=null)
	$status =1;
else
	$status =0;

switch($act)
{
	case 'insert':
	
	if(!empty($txtModulename) ) {
		$strChk = "select count(ModuleId) as chkcnt from a_modules where ModuleName = '$txtModulename' and IsActive != '2'";		
 		$reslt = $db->get_a_line($strChk)->fetchArray();
		if($reslt['chkcnt'] == 0) {
			
			$str="insert into a_modules(ModuleName,Description,ModulePath,IsActive,UserId) values('".getRealescape($db->getconn(),$txtModulename)."','".getRealescape($db->getconn(),$txtModuledescription)."','".getRealescape($db->getconn(),$txtModulepath)."','".$status."','".$_SESSION["UserId"]."')";
			$rslt = $db->query($str);	
									
			//echo json_encode(array("rslt"=>$rslt)); //success
			echo json_encode(array("rslt"=>"1")); //success
		}
		else {
			 echo json_encode(array("rslt"=>"3")); //same exists
		}
	}
	else {
		echo json_encode(array("rslt"=>"4"));  //no values
	}
	
	break;
	
	
	case 'update':	 	
	//$edit_id
	$today=date("Y-m-d");	
	if(!empty($txtModulename) ) {
		$strChk = "select count(ModuleId) as chkcnt from a_modules where ModuleName = '$txtModulename' and IsActive != '2' and ModuleId != '".$edit_id."' ";
 		$reslt = $db->get_a_line($strChk)->fetchArray(); 
		if($reslt['chkcnt'] == 0) {						
			$str = "update a_modules set ModuleName = '".getRealescape($db->getconn(),$txtModulename)."', Description = '".getRealescape($db->getconn(),$txtModuledescription)."', ModulePath = '".getRealescape($db->getconn(),$txtModulepath)."', IsActive = '".$status."', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where ModuleId = '".$edit_id."'";
			$db->query($str);
			
			echo json_encode(array("rslt"=>"2"));
		}
		else {
			echo json_encode(array("rslt"=>"3")); //same exists
		}
	}
	else {
		echo json_encode(array("rslt"=>"4"));  //no values
	}
		
	break;
	
	case 'del':
	  $edit_id = base64_decode($Id);
	  
	  $today = date("Y-m-d");
	  $str="update a_modules set IsActive = '2', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where ModuleId = '".$edit_id."'  and ModuleId NOT IN(1,2,3) ";
	  $db->query($str); 	 
	  
	  echo json_encode(array("rslt"=>"5")); //deletion
	  
	break;
	
	case 'changestatus':
		$edit_id = base64_decode($Id);
		$today = date("Y-m-d");
		$status = $actval;
		
		if($edit_id !="1" && $edit_id !="2" && $edit_id !="3"){			
			$str="update a_modules set IsActive = '".$status."', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where ModuleId = '".$edit_id."' and ModuleId NOT IN(1,2,3) ";
			$db->query($str); 		
			echo json_encode(array("rslt"=>"6")); //status update success		
		}
		else{		 
			echo json_encode(array("rslt"=>"7")); // cannot change status	  
		}
			
	
	break;
}



?>