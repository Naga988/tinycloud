<?php 
require_once '../session.php';
extract($_REQUEST);
$act=$action;

if($chkstatus !=null)
	$status =1;
else
	$status =0;

switch($act)
{
	case 'insert':	
		if(!empty($txtMenuname)) {
			$strChk = "select count(MenuId) as chkcnt from a_menus where MenuName = '".$txtMenuname."' and IsActive != '2'";
			$reslt = $db->get_a_line($strChk)->fetchArray(); 
			if($reslt['chkcnt'] == 0) {
				
				$str="insert into a_menus(MenuName,Description,IsActive,SortingOrder,UserId)values('".$txtMenuname."','".$txtMenuDesc."','".$status."','".$txtSortingorder."','".$_SESSION["UserId"]."')";
				$rslt = $db->query($str);			
				//$log = $db->insert_log("insert","a_menus","","Menu Added Newly","menu",$str);				
				
				echo json_encode(array("rslt"=>"1")); //success
			}
			else {
				 echo json_encode(array("rslt"=>"3")); //same exists
			}
		}
		else {
			echo json_encode(array("rslt"=>"4"));  //no values
		}	
	break;
	
	
	case 'update':	 	
		//$edit_id
		$today=date("Y-m-d");	
		if(!empty($txtMenuname)) {
			$strChk = "select count(MenuId) as chkcnt from a_menus where MenuName = '$txtMenuname' and IsActive != '2' and MenuId != '".$edit_id."' ";
			$reslt = $db->get_a_line($strChk)->fetchArray();
			if($reslt['chkcnt'] == 0) {
				$str = "update a_menus set MenuName = '".$txtMenuname."',Description='".$txtMenuDesc."', SortingOrder = '".$txtSortingorder."', IsActive = '".$status."', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where MenuId = '".$edit_id."'";
				$db->get_a_line($str);
				//$db->insert_log("update","a_menus",$edit_id,"Menu  updated","Menu",$str);

				echo json_encode(array("rslt"=>"2"));
			}
			else {
				echo json_encode(array("rslt"=>"3")); //same exists
			}
		}
		else {
			echo json_encode(array("rslt"=>"4"));  //no values
		}
		
	break;
	
	
	case 'del':
		$edit_id = base64_decode($Id);
	  
		$today = date("Y-m-d");
		$str="update a_menus set IsActive = '2', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where MenuId = '".$edit_id."' and MenuId<>1 ";
		$db->get_a_line($str); 	 
	  
		//$db->insert_log("delete","a_menus",$edit_id,"Menu deleted","Menu",$str);
		echo json_encode(array("rslt"=>"5")); //deletion
	break;
	
	
	case 'changestatus':
		$edit_id = base64_decode($Id);
		$today = date("Y-m-d");
		$status = $actval;
	
		if($edit_id !="1"){
			$str="update a_menus set IsActive = '".$status."', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where MenuId = '".$edit_id."' and MenuId<>1  ";
			$db->get_a_line($str); 	
			echo json_encode(array("rslt"=>"6")); //status update success
		}
		else{		 
			echo json_encode(array("rslt"=>"7")); // cannot change status	  
		}		
	break;	
	
}



?>