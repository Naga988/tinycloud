<?php 
require_once '../session.php';
$menudisp = "ModuleMenu";
include APP_DIR."includes/header.php"; 
include APP_DIR."includes/Mdme-functions.php";
$mdme = getMdmeModulemenu($db,'');
include_once APP_DIR."includes/pagepermission.php";

//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
//check permission - END

$id=$_REQUEST['id'];
if($id!="")
{
	
//check edit permission - START	
if(trim($res_modm_prm['EditPrm'])=="0") {
?>
<script>
  window.location="error.php";
</script>
<?php	
}
//check edit permission - END	

$operation="Edit";
$act="update";
$btn='Update';

$edit_id = base64_decode($id);

$str_ed = "select group_concat(`ModuleId`) as modulelist from a_modulemenus where 1=1 and `IsActive`=1 and `MenuId` =".$edit_id."  ";
$res_ed = $db->get_a_line($str_ed)->fetchArray();

$module_listall = $res_ed['modulelist'];
$module_listarray = explode(",",$module_listall); 

}
else
{
	
//check edit permission - START	
if(trim($res_modm_prm['AddPrm'])=="0") {
?>
<script>
  window.location="error.php";
</script>
<?php	
}
//check edit permission - END


	$operation="Add";
	$act="insert";
	$btn='Save';
}
?>  


<div class="content-part pt-5">
    <div class="container-fluid">
		<div class="row">
			<?php include APP_DIR."common/dpselect-functions.php"; ?>
			<div class="col-md-12">
				<div class="nform p-3">
					<form id="jvalidate" name="frmModuleMenu" action="#" method="post">
						<input type="hidden" name="action" value="<?php echo $act; ?>" />
						<input type="hidden" name="edit_id" value="<?php echo $edit_id; ?> "  />
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">Menu Name <sup class="red">*</sup></label>							
							<?php 
								echo getSelectBox_menulist($db,'dpMenuId','jsrequired','disabled',$edit_id);
							?>
						</div>
						
						<div class="mb-12 module-lists-group">
							<div class="mb-12 d-flex justify-content-between align-items-center ">
								<div class="ftitle" style="width:100%;">
								  <h4>Module List</h4>
								</div>	
							</div>
							
							<div class="mb-12 d-flex">
								<?php 
									  $module_list = $db->get_a_line("select ModuleId,ModuleName from a_modules where 1=1 and IsActive = 1 and ModuleId NOT IN(1,2,3) order by SortingOrder asc ")->fetchAll();
									  foreach($module_list as $module_list_S)
									  {
										  $chek='';
										  if (in_array($module_list_S['ModuleId'], $module_listarray)) {
												$chek = 'checked';
										  }
									?>																
									<div class="col-sm-2 check-boxes">
										<div class="custom-checkbox mb-3">
											<input id="mdlid_<?php echo $module_list_S['ModuleId']; ?>" type="checkbox" name="modulecheck_list[]" value="<?php echo $module_list_S['ModuleId']; ?>" <?php echo $chek; ?> class="checkbox-custom" />
											<label class="checkbox-custom-label" for="mdlid_<?php echo $module_list_S['ModuleId']; ?>"><?php echo $module_list_S['ModuleName']; ?></label>
										</div>										
									</div>
									
									<?php	
									  }
								?>	
							</div>	
						</div>
												
						
						<div class="mb-4 d-flex justify-content-end align-items-center n-btn">						 						  
							<!--<button type="button" class="btn btn-light">Back</button>-->								
							<button class="btn btn-light" type="reset" onClick="javascript:funCancel('frmModuleMenu','jvalidate','modulemenu','modulemenu_mng.php');" >Cancel</button>
							<button class="btn btn-info" type="button" onClick="javascript: return validate_all();" ><span id="spSubmit"><?php echo $btn; ?></span></button>
						</div>
					
					</form>
					
				</div>	
			</div>
		</div>
		
		<div class="row mt-3">
			<div class="col-lg-12">
				<div class="scrollable">
					<div class="table-scroll">									
						<table class="table table-bordered table-hover" cellspacing="0" width="100%" id="tblresult_modulesorting">                                    
							<thead class="mb-2">
								<tr>
									<th>Menu Name</th>
									<th>Module Name</th>
									<th>Sorting Order</th>	
								</tr>
							</thead>
							<tbody>
							<?php
								$modulesorting_list = $db->get_a_line("select t1.*,t2.MenuName,t3.ModuleName,t3.Description,t3.ModulePath from a_modulemenus t1 inner join a_menus t2 on t1.MenuId = t2.MenuId and t2.IsActive =1 inner join a_modules t3 on t1.ModuleId = t3.ModuleId and t3.IsActive =1 where 1=1 and  t1.IsActive =1 and t1.MenuId='".$edit_id."' order by t1.SortingOrder asc ")->fetchAll();
								foreach($modulesorting_list as $modulesorting_list_S)
								{							
								?>
								<tr>
									<td><?php echo $modulesorting_list_S['MenuName']; ?></td>
									<td><?php echo $modulesorting_list_S['ModuleName']; ?></td>
									<td>
										<input type="text" value="<?php echo $modulesorting_list_S['SortingOrder']; ?>" class="form-control"  onkeypress="return isNumber(event)" onchange="changesortingorder('<?php echo $modulesorting_list_S['ModuleMenuId']; ?>',this.value)"  />
									</td>
								</tr>
								<?php			
								}
							?>	
							</tbody>	
						</table>								
					</div>
				</div>						
			</div>
		</div>
				
		
    </div>
 </div>
		  
          
<?php include APP_DIR."includes/footer.php"; ?>  	
<script type="text/javascript"> 
	$(function () {
		$('#tblresult_modulesorting').DataTable({
          "paging": true,
          "lengthChange": true,
          "searching": true,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
	});
	
  function validate_all(){ 
    var chkmodulesel=0;
	if(chkmodulesel == 0){	
		var chkModule=document.getElementsByName('modulecheck_list[]');
		for (var i = 0; i < chkModule.length; i++) {
				if(chkModule[i].checked == true){
					if(chkmodulesel ==0){
						chkmodulesel =1;
					}
				}	
		}
		if(chkmodulesel == 0){				
			swal("Failure!", "Please selecte one or more module permission to this menu.", "warning");
			return false;	
		}
		else{
			funSubmt('frmModuleMenu','modulemenu_actions.php','jvalidate','modulemenu','modulemenu_mng.php');
			return true;
		}		
	}     
  }	

  function changesortingorder(modulemenuId,txtval){	  
	  if(txtval !=""){		  
		  $.ajax({			
			url 	   :'<?php echo BASE_URL; ?>others_actions.php',
			method     : 'POST',
			dataType   : 'json',
			data	   : 'pagename=modulemenusorting&modulemenuId='+modulemenuId+'&sort_value='+txtval+'',			
			success	   : function(response){ 						  		
			}
		});
		  
	  }  
  }
  
</script>

