<?php 
require_once '../session.php';
$menudisp = "Menu";
include APP_DIR."includes/header.php";   
include APP_DIR."includes/Mdme-functions.php"; 
$mdme = getMdmeMenu($db,'');
include_once APP_DIR."includes/pagepermission.php"; 

//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
//check permission - END

$id=$_REQUEST['id'];
if($id!=""){	
	//check edit permission - START	
	if(trim($res_modm_prm['EditPrm'])=="0") {
	?>
	<script>
	  window.location="error.php";
	</script>
	<?php	
	}
	//check edit permission - END	

	$operation="Edit";
	$act="update";
	$btn='Update';

	$str_ed = "select * from a_menus where IsActive != '2' and MenuId = '".base64_decode($id)."' ";
	$res_ed = $db->get_a_line($str_ed)->fetchArray();

	$edit_id = $res_ed['MenuId'];

	$chk='';
	if($res_ed['IsActive']=='1')
	{
		$chk='checked';
	}
}
else
{		
	//check edit permission - START	
	if(trim($res_modm_prm['AddPrm'])=="0") {
	?>
	<script>
	  window.location="error.php";
	</script>
	<?php	
	}
	//check edit permission - END

	$operation="Add";
	$act="insert";
	$btn='Save';
}
?>  

<div class="content-part pt-1">
    <div class="container-fluid">
		<div class="row">
			<div class="col-lg-8 col-md-12">
				<div class="nform p-3">
					<form id="jvalidate" name="frmMenu" action="#" method="post">
						<input type="hidden" name="action" value="<?php echo $act; ?>" />
						<input type="hidden" name="edit_id" value="<?php echo $edit_id; ?> "  />
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label for="txtMenuname" class="form-label">Menu Name <sup class="red">*</sup></label>
							<input type="text" class="form-control jsrequired" name="txtMenuname" id="txtMenuname" value="<?php echo $res_ed['MenuName']; ?>" />							
						</div>
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label for="txtMenuDesc" class="form-label">Description</label>
							<textarea class="form-control" name="txtMenuDesc" id="txtMenuDesc"><?php echo $res_ed['Description']; ?></textarea>								
						</div>
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label for="txtSortingorder" class="form-label">Sorting Order</label>
							<input type="text" class="form-control" name="txtSortingorder" id="txtSortingorder" value="<?php echo $res_ed['SortingOrder']; ?>" onkeypress="return isNumber(event)" />						
						</div>
						
						<div class="mb-4 d-flex">
							<label class="form-label" style="width:27%;">Status</label>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" id="chkstatus" name="chkstatus" <?php echo $chk; ?> />											
							</div>			

							
							
						</div>
						
						<div class="mb-4 d-flex justify-content-end align-items-center n-btn">						 						  
							<!--<button type="button" class="btn btn-light">Back</button>-->
							<button class="btn btn-light" type="reset" onClick="javascript:funCancel('frmMenu','jvalidate','menu','menu_mng.php');" >Cancel</button>							
							<button type="button" class="btn btn-info" onClick="javascript:funSubmt('frmMenu','menu_actions.php','jvalidate','menu','menu_mng.php');"><?php echo $btn; ?></button>						  						  
						</div>
					
					</form>
					
				</div>
			</div>
		</div>
    </div>
 </div>		 
          
<?php include APP_DIR."includes/footer.php"; ?> 

