<?php 
require_once '../session.php';
extract($_REQUEST);
$act=$action;

$moduleid_chkall = $_REQUEST['modulecheck_list'];

switch($act)
{
	case 'insert':			
	break;
		
	case 'update':	 	
	//$edit_id
	$today=date("Y-m-d");	
	
	if(count($moduleid_chkall) > 0)
	{
        $str = "update a_modulemenus set IsActive = 0, UserId='".$_SESSION["UserId"]."'  where MenuId = '".$edit_id."'"; 
		$db->query($str);
				  		
		foreach ($moduleid_chkall as $moduleid_chkall_S)
		{
			$chkmodulethere_ed = $db->get_a_line("select ModuleMenuId from a_modulemenus where MenuId = '".$edit_id."' and ModuleId = '".$moduleid_chkall_S."' ")->fetchArray(); 
			$chk_modulemenuid = $chkmodulethere_ed['ModuleMenuId'];
			
			if (isset($chk_modulemenuid)) {				
				 $db->query("update a_modulemenus set IsActive = '1', UserId='".$_SESSION["UserId"]."' where  ModuleMenuId ='".$chk_modulemenuid."'  ");
			}
			else{
				$db->query("insert into a_modulemenus(ModuleId,MenuId,SortingOrder,UserId,IsActive)values('".$moduleid_chkall_S."','".$edit_id."',0,'".$_SESSION["UserId"]."','1')  ");
			}
		}	
		echo json_encode(array("rslt"=>"2")); //update success
	}
	else{
		echo json_encode(array("rslt"=>"4"));  //no values
	}
				
	break;
	
	case 'del':
	  /*$edit_id = base64_decode($Id);	  
	  $today = date("Y-m-d");*/		 
	  echo json_encode(array("rslt"=>"7")); // cannot change status	  	 
	  	 		
	break;
	
	case 'changestatus':
	  /*$edit_id = base64_decode($Id);	  
	  $today = date("Y-m-d");
	  $status = $actval;*/	  
	  echo json_encode(array("rslt"=>"7")); // cannot change status	  	 
		
	break;
	
}



?>