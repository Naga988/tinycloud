<?php
include 'session.php';
require('fpdf/fpdf.php');
error_reporting(0);
$t=time();

if($_REQUEST){
	if($_REQUEST['rptQuery']){
		$sqlQuery = $_REQUEST['rptQuery'];
		$res = $db->get_a_line($sqlQuery)->fetchAll();
		
		switch($_REQUEST["exportExt"])
		{
			case "excel" :		
				$filename = $_POST["exportFilename"]."_".$t.".xls";		 
				header("Content-Type: application/vnd.ms-excel");
				header("Content-Disposition: attachment; filename=\"$filename\"");
				ExportFile($res);				
				exit();
			case "csv" :	
				$delimiter = ","; 
				$filename = $_POST["exportFilename"]."_".$t.".csv";		 
				
				$f = fopen('php://memory', 'w'); 
				if(!empty($res)){
					$fields  = array_keys($res[0]);
				}
				fputcsv($f, $fields); 
				foreach($res as $rs){
					 fputcsv($f, $rs);
				}
				fseek($f, 0); 
				header("content-type:application/csv;charset=UTF-8");
				header("Content-Disposition: attachment; filename=\"$filename\"");
				fpassthru($f); 				
				exit();
			case "pdf" :
				$filename = $_POST["exportFilename"]."_".$t.".pdf";	
				$pdf = new FPDF(); 
				$pdf->AddPage();
				
				//$width_cell=array(20,50,40,40,40);
				$pdf->SetFont('Arial','B',9);

				//Background color of header//
				$pdf->SetFillColor(193,229,252);
				
				// Header starts /// 
				if(!empty($res)){
					$columns = array_keys($res[0]);
				}
				$tot_columncnt=count($columns);
				for ($x = 0; $x < $tot_columncnt-1; $x++) {
					$pdf->Cell(25,10,$columns[$x],1,0,'L',true);
				}
				$pdf->Cell(25,10,$columns[$x],1,1,'L',true); 	
				//// header ends ///////
								
				$pdf->SetFont('Arial','',8);
				//Background color of header//
				$pdf->SetFillColor(235,236,236); 
				//to give alternate background fill color to rows// 
				$fill=false;
				
				foreach($res as $rs){
					for ($x = 0; $x < $tot_columncnt; $x++) {						
						if($tot_columncnt == ($x+1))
							$pdf->Cell(25,10,$rs[$columns[$x]],1,1,'L',$fill);
						else
							$pdf->Cell(25,10,$rs[$columns[$x]],1,0,'L',$fill);
					}										
					$fill = !$fill;
				}
				
				//$pdf->Output();
				//$pdf->Output('I');
				$pdf->Output('D', $filename);
				
				exit();
			case "print" :
				$filename = $_POST["exportFilename"]."_".$t.".pdf";		 
												
				$pdf = new FPDF(); 
				$pdf->AddPage();
				
				//$width_cell=array(20,50,40,40,40);
				$pdf->SetFont('Arial','B',9);

				//Background color of header//
				$pdf->SetFillColor(193,229,252);
				
				// Header starts /// 
				if(!empty($res)){
					$columns = array_keys($res[0]);
				}
				$tot_columncnt=count($columns);
				for ($x = 0; $x < $tot_columncnt-1; $x++) {
					$pdf->Cell(25,10,$columns[$x],1,0,'L',true);
				}
				$pdf->Cell(25,10,$columns[$x],1,1,'L',true); 	
				//// header ends ///////
								
				$pdf->SetFont('Arial','',8);
				//Background color of header//
				$pdf->SetFillColor(235,236,236); 
				//to give alternate background fill color to rows// 
				$fill=false;
				
				foreach($res as $rs){
					for ($x = 0; $x < $tot_columncnt; $x++) {						
						if($tot_columncnt == ($x+1))
							$pdf->Cell(25,10,$rs[$columns[$x]],1,1,'L',$fill);
						else
							$pdf->Cell(25,10,$rs[$columns[$x]],1,0,'L',$fill);
					}										
					$fill = !$fill;
				}
				
				//$pdf->Output();
				$pdf->Output('I');
								
				exit();
			default :
				die("Unknown action : ");
				break;
		}
			
	}
}
			
function ExportFile($records) {
	$heading = false;
		if(!empty($records))
		  foreach($records as $row) {
			if(!$heading) {
			  // display field/column names as a first row
			  echo implode("\t", array_keys($row)) . "\n";
			  $heading = true;
			}
			echo implode("\t", array_values($row)) . "\n";
		  }
		exit;
}
?>





