<?php
ob_start();ob_flush();
error_reporting(0);
session_start();

if(!empty($_SESSION["UserId"]) && $_SESSION["UserId"]!='' && $_REQUEST['err']!='ses'){
	header("location:dashboard.php");
	exit();
}

?>
<!DOCTYPE html>
<html lang="en">  
<head> 

<?php
	$no_visible_elements=true;
	extract($_POST);
	$error="";
	$msg=" ";

	if(isset($_REQUEST['err'])) {
		$err=$_REQUEST['err'];

		if($err=="invup"){
			$error="<strong>Error!</strong> Invalid Username/Password!";
			$msg="alert-error";
		}
		elseif($err=="invu"){
			$error="<strong>Error!</strong> Invalid Username!";
			$msg="alert-error";
		}
		elseif($err=="lo"){
			$error="<strong>Success!</strong> You have Successfully logged out !";
			$msg="alert-success";
		}
		elseif($err=="invp"){
			$error="<strong>Error!</strong>Invalid Password!";
			$msg="alert-error";
		}	
		elseif($err=="ac"){
			$error="Not Activated Your account!";
			$msg="alert-error";
		}
		elseif($err=="ses"){
			$error="Session Time Out! Please ReLogin.";
			$msg="alert-error";
		}
		else
			$error="";
	}
?>       
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Tiny Cloud</title>
	<link rel="icon" href="assets/images/logo.png" type="image/x-icon" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="assets/css/style.css" type="text/css" >
	<link href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" rel="stylesheet" />

	</head>
    <body>
		<div class="container-fluid d-flex justify-content-center align-items-center fullheight loginbg">
			<div class="form-section col-lg-4 col-md-6 col-12">
				<div class="logo mb-3"><img src="assets/images/logo.png"></div>
				<form id="jvalidate" class="shadow" action="dashboard.php" method="post">
					<h4>Login </h4>
					<div class="form-inner p-4">
						<?php if($error != '' && !empty($error)) { ?>							
							<p class="login-box-msg" style="color:red;"><?php echo $error;?></p>
						<?php } ?>	
												
						<div class="mb-3 relative">
							<input type="text" class="form-control user" name="username" id="username" placeholder="Email">
						</div>
						<div class="mb-3 relative">
							<input type="password" class="form-control pass" name="password" id="password" placeholder="Password">
						</div>
						<input type="hidden" name="submt" id="submt" value="login" />
						<button type="submit" class="btn btn-primary mt-3">Login</button>
					</div>
				</form>
				<div class="mb-3 mt-3">
					<p class="forgot text-center"><a href="#">Forgot Password?</a></p>
				</div>
			</div>
		</div>
					
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
       
    </body>
        
</html>






