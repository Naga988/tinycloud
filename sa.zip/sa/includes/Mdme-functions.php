<?php 
function getMdmeMenu($db,$temp=null)
{	 
$mdme_rslt = getMdme($db,'','adminsettings/menu_mng.php');  
return base64_encode($mdme_rslt['ModuleMenuId']); 
}

function getMdmeModule($db,$temp=null)
{
$mdme_rslt = getMdme($db,'','adminsettings/module_mng.php');
return base64_encode($mdme_rslt['ModuleMenuId']);
}

function getMdmeModulemenu($db,$temp=null)
{
$mdme_rslt = getMdme($db,'','adminsettings/modulemenu_mng.php');
return base64_encode($mdme_rslt['ModuleMenuId']);
}

function getMdmeRole($db,$temp=null)
{
$mdme_rslt = getMdme($db,'','settings/roleinfo_mng.php');
return base64_encode($mdme_rslt['ModuleMenuId']);
}

function getMdmePermissioninfo($db,$temp=null)
{
$mdme_rslt = getMdme($db,'','settings/permissioninfo_mng.php');
return base64_encode($mdme_rslt['ModuleMenuId']);
}

function getMdmeUser($db,$temp=null)
{
$mdme_rslt = getMdme($db,'','settings/userinfo_mng.php');
return base64_encode($mdme_rslt['ModuleMenuId']);
}

function getMdmeCompanySettings($db,$temp=null)
{
$mdme_rslt = getMdme($db,'','settings/companysettings_mng.php');
return base64_encode($mdme_rslt['ModuleMenuId']);
}

?>