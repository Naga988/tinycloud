<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Tiny Cloud</title>
	<!--<link rel="icon" href="<?php echo BASE_URL; ?>favicon.ico?v=2" type="image/x-icon" />-->		
	<link rel="icon" type="image/x-icon" href="<?php echo BASE_URL; ?>assets/images/logo.png" />
	<!--
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
	-->	
	<link href="<?php echo BASE_URL; ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="<?php echo BASE_URL; ?>assets/css/style.css" rel="stylesheet"  type="text/css">
	<link href="<?php echo BASE_URL; ?>assets/css/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
	<link href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" rel="stylesheet" />	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    
	<!-- Selectbox search --> 
    <link type="text/css" href="<?php echo BASE_URL; ?>assets/plugins/select2/select2.min.css" rel="stylesheet" />
	
	<!-- jAlert css -->
    <link type="text/css" href="<?php echo BASE_URL; ?>assets/plugins/sweetalert/sweetalert.css" rel="stylesheet" />
	
	<link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/developer.css">  
    	
</head>
<body>	
	<!-- loader -->
	<div id="overlay">
	  <div class="cv-spinner">
		<span class="spinner"></span>
	  </div>
	</div>
	<!-- loader end -->

	<?php 
		$cls='active';
		include_once "navmenu-functions.php"; 
		$reslt_mnu = getTopMenuArray($db, $_SESSION['RoleId'],$admin_id); 				
	?>
		
	<!-- Side-Nav -->
	<div class="side-navbar active-nav" id="sidebar">
		<div class="side-logo"><a href="#"><img src="<?php echo BASE_URL; ?>assets/images/logo.png" alt=""></a></div>
		<nav class="animated bounceInDown">
			<ul class="text-white w-100 metismenu">
				<li>
					<a href="<?php echo BASE_URL; ?>dashboard.php" class="bill <?php if($menudisp=="Dashboard"){ echo $cls; }?>">
						<img class="menuicon" src="<?php echo BASE_URL; ?>assets/images/menu-icon1.png"> 
						<span class="mx-2">Dashboard</span>
					</a>
				</li>
				
				<?php 
				for($ii=0;$ii<count($reslt_mnu);$ii++) {
				?>
				<li class="sub-menu">					
					<a class="bill" href="javascript:;">
						<img class="menuicon" src="<?php echo BASE_URL; ?>images/menu_icons/<?php echo $reslt_mnu[$ii]['Description']; ?>"> 
						<span class="mx-2"><?php echo $reslt_mnu[$ii]['MenuName']; ?></span>
						<div class="fa fa-caret-down right"></div>
					</a>
					<ul class="mm-collapse">
						<?php 
							$mnuid = $reslt_mnu[$ii]['MenuId']; 
							$reslt_modm = getTopMenuModuleArray($db, $_SESSION['RoleId'],$admin_id,$mnuid);	
							for($nn=0;$nn<count($reslt_modm);$nn++)
							{
								$mdlnam = $reslt_modm[$nn]['ModuleName'];
								$mdlpath = $reslt_modm[$nn]['ModulePath'];	
								$mdldispname = $reslt_modm[$nn]['Description'];
						?>
							<li><a class="bill" href="<?php echo BASE_URL.$mdlpath; ?>"><?php echo $mdldispname; ?></a></li>
						<?php } ?>
					</ul>
				</li>
				<?php } ?>				
			</ul>
		</nav>
	</div>
	<!-- Side-Nav -->

	<!-- Main Wrapper -->
	<div class="my-container active-cont"> 
		<!-- Top Nav -->
		<nav class="navbar top-navbar navbar-light p-0 pt-2 pb-2"> <a class="btn border-0" id="menu-btn"><i class="bx bx-menu"></i></a>
			<div class="container-fluid topnav p-0">
				<div class="row d-flex w-100">
					<div class="col-md-3 d-flex justify-content-start top-btn">
						<div class="dropdown">
							<button class="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"> EN </button>
							<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
								<li><a class="dropdown-item" href="#">English</a></li>
								<li><a class="dropdown-item" href="#">Spanish</a></li>
							</ul>
						</div>
					</div>
		
					<div class="col-md-4 toptitle relative">
						<h4><?php echo $menudisp; ?></h4>
					</div>
					
					<div class="col-md-5 d-flex justify-content-end top-btn">
						<ul>
							<li class="email"> <a class="nav-link nav-icon" href="#"><i class="far fa-envelope"></i></a> </li>
							<!-- Start Notification Dropdown Items -->
							<li class="nav-item dropdown notify"> 
								<a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown" aria-expanded="false"> <i class="far fa-bell"></i> <span class="badge bg-primary badge-number">2</span> </a>
								<ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications" style="">
									<li class="dropdown-header"> You have 4 new notifications <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a> </li>
									<li class="notification-item p-2">
										<div>
											<h4>Lorem Ipsum</h4>
											<p>Quae dolorem earum veritatis oditseno</p>
											<p>30 min. ago</p>
										</div>
									</li>
									<li class="notification-item p-2">
										<div>
											<h4>Lorem Ipsum</h4>
											<p>Quae dolorem earum veritatis oditseno</p>
											<p>30 min. ago</p>
										</div>
									</li>
								</ul>
							</li>
							<!-- End Notification Dropdown Items -->
						</ul>
						
						<?php 									
							if($_SESSION["userPhoto"] != '')
								$usr_photo = $_SESSION["userPhoto"];
							else 	
								$usr_photo = "Ellipse.png";
						?>	
								
						<div class="dropdown"> <img src="<?php echo BASE_URL; ?>uploads/adminusers/<?php echo $usr_photo; ?>" >
							<button class="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"> <?php echo $_SESSION["UName"]; ?> </button>
							<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
								<li><a class="dropdown-item" href="#">My Profile</a></li>
								<li><a class="dropdown-item" href="<?php echo BASE_URL; ?>logout.php">Logout</a></li>
							</ul>
						</div>
						<div class="dropdown"> <a class="nav-link nav-icon" href="<?php echo BASE_URL; ?>logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a> </div>
					</div>
				</div>
			</div>
		</nav>
		<!--End Top Nav -->

