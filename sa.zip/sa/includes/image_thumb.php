<?php
////-----------------------------------For Creating Thumbnails,screen shots i used this function------------//////	
class Gthumb
{
    /////////////////////////////////// For photos ////////////////////////////////////
	function genThumbAdminusersImage($bannertype, $indx=0)
	{      	
		if($_FILES[$bannertype]["name"] != "") {						

			$newf=str_replace(' ','_',$_FILES[$bannertype]["name"]);
			$newf=$gallname=time().rand(0,9).$newf;			

			move_uploaded_file($_FILES[$bannertype]["tmp_name"],"uploads/adminusers/". $newf);	
			//--------------------------------------thumbnails---------------------------			// The file			

			$filename = "uploads/adminusers/".$gallname;
			list($width, $height) = getimagesize($filename);

			if($width>=$height)
			{
				$new_width = 206;
				$new_height=$new_width * $height / $width;	
			}
			else
			{
				$new_height=150;
				$new_width=$new_height * $width / $height;
			}

			// Resample
			//$new_width = 206;  $new_height=102;
			$image_p = imagecreatetruecolor($new_width, $new_height);		

			//$image = imagecreatefromjpeg($filename);

			if ($_FILES[$bannertype]["type"] == "image/gif")
			$image = imagecreatefromgif($filename);		
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			$image = imagecreatefrompng($filename);

			imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

			$location = "uploads/adminusers/thumbnails/".$gallname;
			// Output 	//imagejpeg($image_p,$location, 100);
			if ($_FILES[$bannertype]["type"] == "image/gif")
			imagegif($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			imagepng($image_p,$location, 9);
		//--------------------------------------------------------end of thumbnails--------------------------------------
		}
		return 	$newf;		
	}
	

/////////////////////////////////// Main company logo - START ////////////////////////////////////	
	
	function genThumbCompanyLogo($bannertype, $indx=0)
	{      	
		if($_FILES[$bannertype]["name"] != "") {						

			$newf=str_replace(' ','_',$_FILES[$bannertype]["name"]);
			$newf=$gallname=time().rand(0,9).$newf;			

			move_uploaded_file($_FILES[$bannertype]["tmp_name"],"uploads/company_logo/". $newf);	
			//--------------------------------------thumbnails---------------------------			// The file			

			$filename = "uploads/company_logo/".$gallname;
			list($width, $height) = getimagesize($filename);

			if($width>=$height)
			{
				$new_width = 206;
				$new_height=$new_width * $height / $width;	
			}
			else
			{
				$new_height=150;
				$new_width=$new_height * $width / $height;
			}

			// Resample
			//$new_width = 206;  $new_height=102;
			$image_p = imagecreatetruecolor($new_width, $new_height);		

			//$image = imagecreatefromjpeg($filename);

			if ($_FILES[$bannertype]["type"] == "image/gif")
			$image = imagecreatefromgif($filename);		
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			$image = imagecreatefrompng($filename);

			imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

			$location = "uploads/company_logo/thumbnails/".$gallname;
			// Output 	//imagejpeg($image_p,$location, 100);
			if ($_FILES[$bannertype]["type"] == "image/gif")
			imagegif($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			imagepng($image_p,$location, 9);
		//--------------------------------------------------------end of thumbnails--------------------------------------
		}
		return 	$newf;		
	}
	
/////////////////////////////////// Main company logo - END ////////////////////////////////////		
	

/////////////////////////////////// Customer company logo - START ////////////////////////////////////	
	
	function genThumbCustomer_logo($bannertype, $indx=0)
	{      	
		if($_FILES[$bannertype]["name"] != "") {						

			$newf=str_replace(' ','_',$_FILES[$bannertype]["name"]);
			$newf=$gallname=time().rand(0,9).$newf;			

			move_uploaded_file($_FILES[$bannertype]["tmp_name"],"uploads/customer_logo/". $newf);	
			//--------------------------------------thumbnails---------------------------			// The file			

			$filename = "uploads/customer_logo/".$gallname;
			list($width, $height) = getimagesize($filename);

			if($width>=$height)
			{
				$new_width = 206;
				$new_height=$new_width * $height / $width;	
			}
			else
			{
				$new_height=150;
				$new_width=$new_height * $width / $height;
			}

			// Resample
			//$new_width = 206;  $new_height=102;
			$image_p = imagecreatetruecolor($new_width, $new_height);		

			//$image = imagecreatefromjpeg($filename);

			if ($_FILES[$bannertype]["type"] == "image/gif")
			$image = imagecreatefromgif($filename);		
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			$image = imagecreatefrompng($filename);

			imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

			$location = "uploads/customer_logo/thumbnails/".$gallname;
			// Output 	//imagejpeg($image_p,$location, 100);
			if ($_FILES[$bannertype]["type"] == "image/gif")
			imagegif($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			imagepng($image_p,$location, 9);
		//--------------------------------------------------------end of thumbnails--------------------------------------
		}
		return 	$newf;		
	}
	
/////////////////////////////////// customer company logo - END ////////////////////////////////////	




/////////////////////////////////// customer image - START ////////////////////////////////////	
	
	function genThumbCustomer_image($bannertype, $indx=0)
	{      	
		if($_FILES[$bannertype]["name"] != "") {						

			$newf=str_replace(' ','_',$_FILES[$bannertype]["name"]);
			$newf=$gallname=time().rand(0,9).$newf;			

			move_uploaded_file($_FILES[$bannertype]["tmp_name"],"uploads/customer_image/". $newf);	
			//--------------------------------------thumbnails---------------------------			// The file			

			$filename = "uploads/customer_image/".$gallname;
			list($width, $height) = getimagesize($filename);

			if($width>=$height)
			{
				$new_width = 206;
				$new_height=$new_width * $height / $width;	
			}
			else
			{
				$new_height=150;
				$new_width=$new_height * $width / $height;
			}

			// Resample
			//$new_width = 206;  $new_height=102;
			$image_p = imagecreatetruecolor($new_width, $new_height);		

			//$image = imagecreatefromjpeg($filename);

			if ($_FILES[$bannertype]["type"] == "image/gif")
			$image = imagecreatefromgif($filename);		
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			$image = imagecreatefromjpeg($filename);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			$image = imagecreatefrompng($filename);

			imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

			$location = "uploads/customer_image/thumbnails/".$gallname;
			// Output 	//imagejpeg($image_p,$location, 100);
			if ($_FILES[$bannertype]["type"] == "image/gif")
			imagegif($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/jpeg")
			imagejpeg($image_p,$location, 50);
			elseif ($_FILES[$bannertype]["type"] == "image/png")
			imagepng($image_p,$location, 9);
		//--------------------------------------------------------end of thumbnails--------------------------------------
		}
		return 	$newf;		
	}
	
/////////////////////////////////// customer image - END ////////////////////////////////////	

	
	
}

?>