<?php 

function getTopMenuArray($db, $RoleId=null,$admin_id=null) 
{

	$str_Pra="";
	if($admin_id != '' && $_SESSION['RoleId'] != '0') 
	{ 	
		$strmenu=" m_us.UserId = '".$admin_id."' and m_md.IsActive=1 ";
		if($_SESSION['RoleId']==1)
			$strmenu=" m_md.IsActive=1 and m_rp.RoleId=1 ";	
	
		$select_mnu = "SELECT distinct m_me.MenuName,m_mdm.MenuId,m_me.Description FROM a_modules m_md inner join a_modulemenus m_mdm on m_mdm.ModuleId = m_md.ModuleId inner join a_menus m_me on m_me.MenuId = m_mdm.MenuId inner join a_user_acl m_rp on m_rp.ModuleMenuId = m_mdm.ModuleMenuId inner join a_users m_us on m_us.RoleId = m_rp.RoleId and m_us.IsActive = '1' WHERE m_rp.RoleId=".$_SESSION['RoleId']." and m_md.IsActive = '1' and m_mdm.IsActive = 1 and m_me.IsActive = 1 and m_rp.IsActive = 1  group by m_rp.ModuleMenuId order by m_me.SortingOrder, m_mdm.MenuId, m_mdm.SortingOrder ";	
		
	} 	
	return $db->get_a_line($select_mnu)->fetchAll(); 

}

function getTopMenuModuleArray($db, $RoleId=null,$admin_id=null,$MnuId) 
{

	$str_Pra="";
	if($admin_id != '' && $_SESSION['RoleId'] != '0') 
	{ 
		$strmenu=" m_us.UserId = '".$admin_id."' and m_md.IsActive=1 ";
		if($_SESSION['RoleId']==1)
			$strmenu=" m_md.IsActive=1 and m_rp.RoleId=1 ";

	  	 $select_modm = "SELECT m_me.MenuName,m_md.ModuleName, m_md.ModulePath,m_md.Description, m_rp.ModuleMenuId FROM a_modules m_md inner join a_modulemenus m_mdm on m_mdm.ModuleId = m_md.ModuleId inner join a_menus m_me on m_me.MenuId = m_mdm.MenuId inner join a_user_acl m_rp on m_rp.ModuleMenuId = m_mdm.ModuleMenuId inner join a_users m_us on m_us.RoleId = m_rp.RoleId and m_us.IsActive = '1' WHERE m_rp.RoleId=".$_SESSION['RoleId']."  and m_me.IsActive = 1 and m_md.IsActive=1 and m_mdm.MenuId = ".$MnuId." and m_rp.IsActive = 1  and m_mdm.IsActive = 1 group by m_rp.ModuleMenuId order by m_me.SortingOrder, m_mdm.MenuId, m_mdm.SortingOrder ";
	}		

	return $db->get_a_line($select_modm)->fetchAll();  
}


function getModuleTitle($db,$modulePath){
	$str_Pra="";	 	
	$select_modm = "SELECT ModuleName FROM a_modules where ModulePath = '$modulePath' ";		
	return $db->get_a_line($select_modm)->fetchAll(); 
}
	
?>