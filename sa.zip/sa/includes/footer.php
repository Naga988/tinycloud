	<section class="footer-section">
		<div class="container-fluid">
		  <div class="row">
			<div class="col-12">
			  <p>© 2022 Tiny Cloud </p>
			</div>
		  </div>
		</div>
	</section>
</div>
<form action="../download_file.php" method="post" id="frmExport" target="_blank">											
	<input type="hidden" name="exportExt" id="exportExt" />
	<input type="hidden" name="exportFilename" id="exportFilename" />
	<textarea hidden="hidden" name="rptQuery" id="rptQuery" ></textarea>       
</form>
</body>
	<!--
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.1.0/js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
	-->
	
	
	<script src="<?php echo BASE_URL; ?>assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo BASE_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo BASE_URL; ?>assets/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo BASE_URL; ?>assets/js/dataTables.responsive.min.js"></script>
	<script src="<?php echo BASE_URL; ?>assets/js/dataTables.bootstrap.min.js"></script>
	
	<!--<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script>--> 

	<!-- validation -->    
    <script src="<?php echo BASE_URL; ?>assets/plugins/validation/jquery.validate.js" type="text/javascript"></script> 
    <script src="<?php echo BASE_URL; ?>assets/plugins/validation/additional-methods.js" type="text/javascript"></script> 
	
	<!-- Selectbox search -->    
     <script src="<?php echo BASE_URL; ?>assets/plugins/select2/select2.full.min.js" type="text/javascript"></script> 
	
	<!-- jAlert -->    
    <script src="<?php echo BASE_URL; ?>assets/plugins/sweetalert/sweetalert-dev.js" type="text/javascript"></script> 
		
	<script>
	/******menu part start*********/
	var menu_btn = document.querySelector("#menu-btn");
	var sidebar = document.querySelector("#sidebar");
	var container = document.querySelector(".my-container");
	  menu_btn.addEventListener("click", () => {
	  sidebar.classList.toggle("active-nav");
	  container.classList.toggle("active-cont");
	});

	$('.sub-menu ul').hide();
	$(".sub-menu a").click(function () {
		$(this).parent(".sub-menu").children("ul").slideToggle("100");
		$(this).find(".right").toggleClass("fa-caret-up fa-caret-down");
	});
	</script>
	
	<script type="text/javascript">		
		function loading() {			
			//document.getElementById("load").style.display = 'block';	
			$("#overlay").fadeIn(300);	
		}

		function unloading() {
			//document.getElementById("load").style.display = 'none';
			$("#overlay").fadeOut(300);
		}
	</script>
	
	<script type="text/javascript">
		var sucmsg = 'has been added successfully';
		var exsmsg = 'Already Exists';
		var upmsg  = 'has been updated successfully';
		var reqmsg = 'Required fields should not be empty';
		var delmsg = 'Deleted successfully';
		var statusmsg= 'Status updated successfully';
		var exsmsg_email = 'Email ID already exists. Please try with other email ID to create account.';
		var exsmsg_phone = 'Mobile number already exists. Please try with other mobile number create account.';
		var exsmsg_reference = 'Reference exists with other data. Cannot be deleted.';
		var oldpass_reference = 'Old Password doesn`t match. Please enter right password.';
		var othmsg = 'Opps!!@ Server Error. Please retry again.';
		var exsmsg_refstats = 'Reference exists with other data. Cannot Perform the action.';
		var dataGridHdn; 
		
		$(function () {			 
			$(".select2").select2();
		});
		
		//submenu highlight function - START
		jQuery(document).ready(function($){ 
			//debugger;
			var currentPath  = window.location.pathname;	
			var splitPath = currentPath.split('/');
			var cPath = splitPath[splitPath.length-1];	
			if(cPath.indexOf('_') != -1){		
				var cPathSplit = cPath.split('_');        	
				if(cPathSplit[0].length > 0){		
					$('.mm-collapse li a').removeClass('active');		
					$('.metismenu a').each(function(){				
						var href = $.trim($(this).attr('href'));
						var splithref = href.split('/');
						href = splithref[splithref.length-1];						
						var hrefSplit = href.split('_');				
						if(hrefSplit[0] == cPathSplit[0]){					
							//$(this).closest('li').addClass('active');
							$(this).addClass('active');
							$(this).closest('ul').addClass('mm-show');
							//$(this).closest('ul').parent().addClass('mm-active');				
						}
					});
				}
			}
		});
		

		/*
		if (containsSpecialChars(href)) {
							var a = href.split('/');
							href=a[1];
						}		
		function containsSpecialChars(str) {
			//const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
			const specialChars = /[\/]/;
			return specialChars.test(str);
		}
		
		*/
		
		//submenu highlight function - END
 
		//Accept Number only function - START
		function isNumber(evt) {
			evt = (evt) ? evt : window.event;
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57)) {
				return false;
			}
			return true;
		}
		//Accept Number only function - END

		function isNumberKey(evt)
		{
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
				return false;
			
		    return true;
		}


		//Data table all page display grid common function - START		
		function datatblCal(hdnFld)
		{
			var iColumns = $('#tblresult thead th').length;  // count all column length
			var sortrmvcloumn1 = parseInt(iColumns-2); // sorting remove to action column
			var sortrmvcloumn2 = parseInt(iColumns-1); // sorting remove to status column
			
			var i=0;
			var dataTable = $('#tblresult').dataTable( {		
			initComplete: function () {
				if(typeof hdnFld !='undefined'){				
				}	
				unloading(); 
				$('.buttons-copy').html('<i class="fa fa-copy" />')
				   $('.buttons-csv').html('<i class="fa fa-file-text-o" />')
				   $('.buttons-excel').html('<img src="assets/images/xl-icon.png" alt="">')
				   $('.buttons-pdf').html('<i class="fa fa-file-pdf-o" />')
				   $('.buttons-print').html('<i class="fa fa-print" />')
			},					
				"processing": true,
				//aoColumnDefs: [ { bSortable: true, aTargets: [ '_all' ] },{ bSortable: true, aTargets: [0] }],
				"columnDefs": [ { "targets": [sortrmvcloumn1,sortrmvcloumn2], "orderable": false } ],
				"destroy" : true,
				"serverSide": true,
				"stateSave": true,
				"bStateSave" : false,
				"language": { 
					paginate: {
						next: "<i class='ti-arrow-right'></i>",
						previous: "<i class='ti-arrow-left'></i>"
					},
					"processing": loading() 
				},
				"ajax":{
					url :'<?php echo BASE_URL; ?>display-grid-data.php?finaltab='+$('#disptblname').val(), // json datasource
					type: "post",  // method  , by default get
					error: function(){  // error handling                  
						$("#tblresult").append('<tbody class="employee-grid-error"><tr><th colspan="4">No data found in the server</th></tr></tbody>');
						unloading(); 
					}
				},	
				/*dom: 'lBfrtip',
				buttons: [
					{
					extend: 'excel', 
					exportOptions: {
						columns: [0,1] // Column index which needs to export
					},
					//text: 'Export to Excel',
					footer: true,
					filename: function(){
							var d = new Date();
							var n = d.getTime();
							return $('#disptblname').val()+'_report_'+n;
						}
					}
				]*/				
			} ); 
		}
		
		function datatblCal_new(hdnFld)
		{
			var iColumns = $('#tblresult thead th').length;  // count all column length
			var sortrmvcloumn1 = parseInt(iColumns-2); // sorting remove to action column
			var sortrmvcloumn2 = parseInt(iColumns-1); // sorting remove to status column
			
			var i=0;
			var dataTable = $('#tblresult').DataTable({
				initComplete: function () {
					if(typeof hdnFld !='undefined'){				
					}	
					unloading(); 
				},					
				bLengthChange: true,
				"bDestroy": true,
				"serverSide": true,
				"stateSave": true,
				"bStateSave" : false,
				language: {
					search: "<i class='ti-search'></i>",
					searchPlaceholder: 'Quick Search',
					paginate: {
						next: "<i class='ti-arrow-right'></i>",
						previous: "<i class='ti-arrow-left'></i>"
					},
					"processing": loading()
				},
				columnDefs: [ { "targets": [sortrmvcloumn1,sortrmvcloumn2], "orderable": false } ],
				responsive: true,
				searching: true,
				info: true,
				paging: true,
				"ajax":{
					url :"display-grid-data.php?finaltab="+$('#disptblname').val(), // json datasource
					type: "post",  // method  , by default get
					error: function(){  // error handling                  
						$("#tblresult").append('<tbody class="employee-grid-error"><tr><th colspan="4">No data found in the server</th></tr></tbody>');
						unloading(); 
					}
				}
			});
		}
		//Data table all page display grid common function - END

	
		//Save data to db all page common function - START		
		function funSubmt($frm,$urll,$acts,$stats,$lodlnk)
		{ 
			if ($('#'+$acts).valid()) {
				$("button").attr('disabled',true);
				
				$.ajax({
					url        : $urll,
					method     : 'POST',
					dataType   : 'json',
					data       : $("#"+$acts).serialize(),
					beforeSend: function() {
						loading();
					},
					success: function(response){ 
					
						if(response.rslt == "1"){
							swal("Success!", $stats +' '+ sucmsg, "success");										
							$("#"+$acts)[0].reset();
							$(location).attr('href', $lodlnk);
						}
						else if(response.rslt == "2"){
							swal("Update!", $stats +' '+ upmsg, "success");
							$("#"+$acts)[0].reset();
							$(location).attr('href', $lodlnk);
						}			
						else if(response.rslt == "3"){
							swal("Failure!", $stats +' '+ exsmsg, "warning");
						}
						else if(response.rslt == "4"){
							swal("Failure!", $stats +' '+ reqmsg, "warning");
						}
						else{
							swal("Failure!", othmsg, "warning");
						}		
					
						unloading();
						$("button").attr('disabled',false); 
						
					}
				});
			}	
		}
		//Save data to db all page common function - END
		
		
		//Save data to db Image upload page common function - START		
		function funSubmtWithImg($frm,$urll,$acts,$stats,$lodlnk)
		{    	
		//alert($stats)
			if ($('#'+$acts).valid()) {
				$("button").attr('disabled',true);
				
				var m_data = new FormData();
				var disabled = $('#'+$acts).find(':input:disabled').removeAttr('disabled');
				
				var formdatas = $("#"+$acts).serializeArray();	
				disabled.attr('disabled','disabled');		
				
				$.each( formdatas, function( key, value ) {
					 m_data.append( value.name, value.value);							 
				});
				/*
				if($stats == 'user'){			
					m_data.append( 'user_photo', $('input[name=user_photo]')[0].files[0]);			
				}
				else if($stats == 'customer'){			
					m_data.append( 'customer_logo', $('input[name=cus_company_logo]')[0].files[0]);	
					m_data.append( 'customer_img', $('input[name=cus_image]')[0].files[0]);
				}
				*/
				
				$.ajax({
					url        : $urll,
					type	   : 'POST',
					dataType   : 'json',
					processData: false,
					contentType: false,
					data       : m_data,
					beforeSend: function() {
						loading();
					},
					success: function(response){ 
					
						if(response.rslt == "1"){
							swal("Success!", $stats +' '+ sucmsg, "success");										
							$("#"+$acts)[0].reset();
							$(location).attr('href', $lodlnk);
						}
						else if(response.rslt == "2"){
							swal("Update!", $stats +' '+ upmsg, "success");
							$("#"+$acts)[0].reset();
							$(location).attr('href', $lodlnk);
						}			
						else if(response.rslt == "3"){
							swal("Failure!", $stats +' '+ exsmsg, "warning");
						}
						else if(response.rslt == "4"){
							swal("Failure!", $stats +' '+ reqmsg, "warning");
						}
						else{
							swal("Failure!", othmsg, "warning");
						}		
					
						unloading();
						$("button").attr('disabled',false); 
						
					}
				});
			}	
		}
		//Save data to db Image upload page common function - END	
		
		//Cancel all page common function - START	 
		function funCancel($frm,$acts,$stats,$lodlnk)
		{  
			swal({
				title: "Are you sure?",
				text: "Are you sure to cancel?",
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "Ok",
				closeOnConfirm: true
			},
			function () {
				$("#"+$acts)[0].reset();
				$(location).attr('href', $lodlnk);
			});
		}
		//Cancel all page common function - END
		
		//Active / inactive change all page common function - START
		function funchangestatus(t,$frm,$par){			
			swal({
				title: "Are you sure?",
				text: "Sure You want to change the status?",
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "Yes, Change it!",
				closeOnConfirm: true
			},
			function () {
				$.ajax({		
					url        : $frm,
					method     : 'POST',
					dataType   : 'json',
					data       : $par,
					beforeSend: function() {
						loading();
					},
					success: function(response){ 
						unloading();
						if(response.rslt == '6')
						{					
							swal("Success!", statusmsg, "success");	
							datatblCal(dataGridHdn);
						}
						else if(response.rslt == '7')
						{					
							swal("Failure!", exsmsg_refstats, "warning");	
						}
						else{
							swal("Failure!", othmsg, "warning");
						}	
					}		
				});	
			}); 
		}
		//Active / inactive change all page common function - END
		
	
	
		//Export option for common - START
		function export_options(exportExt, exporttblname, $acts){
				
			if(exportExt){
				var m_data = new FormData();				
				m_data.append('exportExt', exportExt);	
				m_data.append('exporttblname', exporttblname);

				if($acts !=''){
					var formdatas = $("#"+$acts).serializeArray();									
					$.each( formdatas, function( key, value ) {
						 m_data.append( value.name, value.value);							 
					});
				}				
								
				$.ajax({					
					url 	   :'<?php echo BASE_URL; ?>generate_export.php',
					type	   : 'POST',
					dataType   : 'json',
					processData: false,
					contentType: false,
					data       : m_data,
					beforeSend: function() {
						loading();
					},
					success: function(response){ 
						if(response.rslt == "1"){
							//swal("Success!","succ", "success");	
							$('#exportExt').val(exportExt);
							$('#exportFilename').val(exporttblname);
							$("#rptQuery").html(response.sqlquery);
							$('#frmExport').submit();	

							$('#exportExt').val('');
							$('#exportFilename').val('');
							$("#rptQuery").html('');
						}
						else if(response.rslt == "2"){
							swal("Failure!", response.err_msg, "warning");
						}
						else{
							swal("Failure!", "Something went wrong, Please try some time!!!", "warning");
						}		
						
						unloading();
					}
				});												
			}		
					
		}	
	
		//Export option for common - END
	
	
	</script>	
</html>