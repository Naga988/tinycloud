<?php 

function getSelectBox_menulist($db, $SelName, $jrequired,$Attr,$selId=null) {
	if($StrQry ==''){		
		$StrQry="select MenuId AS Id,MenuName AS Name from a_menus where IsActive = '1' order by MenuName asc";
	}	
	$resQry = $db->get_a_line($StrQry)->fetchAll();		 
	$strSelHtml =  "<select class='form-control select2 ".$jrequired."' id='".$SelName."' name='".$SelName."'  ".$Attr." ><option value=''>Select</option>";
	
	if(!empty($resQry)) {
		foreach($resQry as $val) {
		$sel='';
			if($selId==$val['Id'])
				$sel=' selected="selected" ';
			$strSelHtml=$strSelHtml."<option value=".$val['Id']." ".$sel.">".$val['Name']."</option>";
		}
	}
	
	$strSelHtml=$strSelHtml."</select>";
	
	return $strSelHtml;	
}


function getSelectBox_rolelist($db, $SelName, $Attr,$selId=null) {
	if($StrQry ==''){		
		$StrQry="select RoleId AS Id,RoleName AS Name from a_roles where IsActive = '1' and RoleId <> 1 order by RoleName asc";
	}	
	$resQry = $db->get_a_line($StrQry)->fetchAll();		
	$strSelHtml =  "<select class='form-control select2 ".$Attr."' id='".$SelName."' name='".$SelName."' ><option value=''>Select</option>";
	
	if(!empty($resQry)) {
		foreach($resQry as $val) {
		$sel='';
			if($selId==$val['Id'])
				$sel=' selected="selected" ';
			$strSelHtml=$strSelHtml."<option value=".$val['Id']." ".$sel.">".$val['Name']."</option>";
		}
	}
	
	$strSelHtml=$strSelHtml."</select>";
	
	return $strSelHtml;	
}

function getSelectBox_countrylist($db, $SelName, $Attr,$selId=null,$prop=null) {
	if($StrQry ==''){		
		$StrQry="select countryid AS Id,countryname AS Name from can_country where IsActive = '1' order by countryname asc";
	}	
	$resQry = $db->get_a_line($StrQry)->fetchAll();		
	$strSelHtml =  "<select class='form-control select2 ".$Attr."' id='".$SelName."' name='".$SelName."' ".$prop." ><option value=''>Select</option>";
	
	if(!empty($resQry)) {
		foreach($resQry as $val) {
		$sel='';
			if($selId==$val['Id'])
				$sel=' selected="selected" ';
			$strSelHtml=$strSelHtml."<option value=".$val['Id']." ".$sel.">".$val['Name']."</option>";
		}
		
	}
	
	$strSelHtml=$strSelHtml."</select>";
	
	return $strSelHtml;	
}

?>