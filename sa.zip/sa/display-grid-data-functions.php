<?php 

//Menu List Display Grid - START
function getMenuArray_tot($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
	$str_all="select * from a_menus where 1=1 and IsActive <>2 and MenuId NOT IN(1) ";
	$res = $db->get_a_line($str_all)->fetchAll();
	return $totalData = count($res);
}

function getMenuArray_Ajx($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
		$str_all="select * from a_menus where 1=1 and IsActive <> 2 and MenuId NOT IN(1)"; 		
		$rescntchk =  $db->get_a_line($str_all)->fetchAll(); 
	
		if($whrcon != "")
		$str_all .= $whrcon;	
	
		$totalFiltered =  $totalData; 
		
		if(trim($ordr) != "")
		$str_all .= $ordr;
		
		if($stt != "")
		$str_all .= "limit ".$stt.",".$len;		
	
		$res = $db->get_a_line($str_all)->fetchAll(); 
		$totalData = count($rescntchk);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
	
		return $res; 			
}
//Menu List Display Grid - END

//Module List Display Grid - START

function getModuleArray_tot($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
	$str_all="select * from a_modules where 1=1 and IsActive <>2 and ModuleId NOT IN(1,2,3) ";
	$res = $db->get_a_line($str_all)->fetchAll();
	return $totalData = count($res);
}

function getModuleArray_Ajx($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
		$str_all="select * from a_modules where 1=1 and IsActive <> 2 and ModuleId NOT IN(1,2,3) "; 		
		$rescntchk =  $db->get_a_line($str_all)->fetchAll(); 
	
		if($whrcon != "")
		$str_all .= $whrcon;	
	
		$totalFiltered =  $totalData; 
		
		if(trim($ordr) != "")
		$str_all .= $ordr;
		
		if($stt != "")
		$str_all .= "limit ".$stt.",".$len;	       
	
		$res = $db->get_a_line($str_all)->fetchAll(); 
		$totalData = count($rescntchk);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
	
		return $res; 			
}
//Module List Display Grid - END


//ModuleMenu List Display Grid - START

function getModuleMenuArray_tot($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
    $str_all="select * from a_menus where IsActive = '1'  "; //and MenuId NOT IN(1)

	$res = $db->get_a_line($str_all)->fetchAll();
	return $totalData = count($res);
}


function getModuleMenuArray_Ajx($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
        $str_all="select * from a_menus where IsActive = '1' "; //and MenuId NOT IN(1) 

		$rescntchk =  $db->get_a_line($str_all)->fetchAll(); 
	
		if($whrcon != "")
		$str_all .= $whrcon;	
	
		$totalFiltered =  $totalData; 
		
		if(trim($ordr) != "")
		$str_all .= $ordr;
		
		if($stt != "")
		$str_all .= "limit ".$stt.",".$len;	  	
	
		$res = $db->get_a_line($str_all)->fetchAll(); 
		$totalData = count($rescntchk);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
	
		return $res; 			
}
//ModuleMenu List Display Grid - END


//Permission Info List Display Grid - START

function getPermissionInfoArray_tot($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{
	if($_SESSION["UserId"] =="1" || $_SESSION["UserId"]==1)	
		$str_all="select * from a_roles where IsActive = '1' "; //and RoleId NOT IN(1) 
	else
		$str_all="select * from a_roles where IsActive = '1' and RoleId NOT IN(1) ";
		
    
	$res = $db->get_a_line($str_all)->fetchAll();
	return $totalData = count($res);
}


function getPermissionInfoArray_Ajx($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{
		if($_SESSION["UserId"] =="1" || $_SESSION["UserId"]==1)	
			$str_all="select * from a_roles where IsActive = '1' "; //and RoleId NOT IN(1) 
		else
			$str_all="select * from a_roles where IsActive = '1' and RoleId NOT IN(1) ";

		$rescntchk =  $db->get_a_line($str_all)->fetchAll(); 
	
		if($whrcon != "")
		$str_all .= $whrcon;	
	
		$totalFiltered =  $totalData; 
		
		if(trim($ordr) != "")
		$str_all .= $ordr;
		
		if($stt != "")
		$str_all .= "limit ".$stt.",".$len;	  	
	
	//echo $str_all; die();
	
		$res = $db->get_a_line($str_all)->fetchAll(); 
		$totalData = count($rescntchk);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
	
		return $res; 			
}

//Permission Info List Display Grid - END



//Role List Display Grid - START
function getRoleArray_tot($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
	$str_all="select * from a_roles where 1=1 and IsActive <>2 and RoleId NOT IN(1)";
	$res = $db->get_a_line($str_all)->fetchAll();
	return $totalData = count($res);
}

function getRoleArray_Ajx($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
		$str_all="select * from a_roles where 1=1 and IsActive <> 2 and RoleId NOT IN(1) "; 		
		$rescntchk =  $db->get_a_line($str_all)->fetchAll(); 
	
		if($whrcon != "")
		$str_all .= $whrcon;	
	
		$totalFiltered =  $totalData; 
		
		if(trim($ordr) != "")
		$str_all .= $ordr;
		
		if($stt != "")
		$str_all .= "limit ".$stt.",".$len;	       
	
		$res = $db->get_a_line($str_all)->fetchAll(); 
		$totalData = count($rescntchk);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
	
		return $res; 			
}
//Role List Display Grid - END

//User List Display Grid - START
function getUserArray_tot($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
	$str_all="select u.*,r.RoleName from a_users u LEFT JOIN  a_roles r on u.RoleId = r.RoleId where  u.IsActive <> 2 and u.user_ID <> 1   "; 	
	$res = $db->get_a_line($str_all)->fetchAll();
	return $totalData = count($res);
}

function getUserArray_Ajx($db, $act=null,$whrcon=null,$ordr=null,$stt=null,$len=null) 
{	
		$str_all="select u.*,r.RoleName from a_users u LEFT JOIN  a_roles r on u.RoleId = r.RoleId where  u.IsActive <> 2 and u.user_ID <> 1   "; 		
		$rescntchk =  $db->get_a_line($str_all)->fetchAll(); 
	
		if($whrcon != "")
		$str_all .= $whrcon;	
	
		$totalFiltered =  $totalData; 
		
		if(trim($ordr) != "")
		$str_all .= $ordr;
		
		if($stt != "")
		$str_all .= "limit ".$stt.",".$len;	       
	
		$res = $db->get_a_line($str_all)->fetchAll(); 
		$totalData = count($rescntchk);
		$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.
	
		return $res; 			
}
//User List Display Grid - END

?>