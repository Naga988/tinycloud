<?php
include "includes/header.php";
?>

<div class="content-part pt-1">
    <div class="container-fluid">
	
		<div class="row">
			<div class="col-md-4 toptitle">
				<h4 style="float:left;">Access Denied</h4>
			</div>
		</div>
			  
		<div class="row">
            <div class="col-md-12">	
				<div class="box box-info"> 
                  <div class="box-body">				 	
					  <div class="" style="font-weight:bold; font-size:24px; min-height:200px;" >You don't have permission to access this page</div>
                  </div>
              </div>			
			</div>
         </div>   
	  
    </div>
</div>


<?php include "includes/footer.php"; ?>