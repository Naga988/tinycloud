<?php
//include 'session.php';
//error_reporting(-1);
extract($_REQUEST);

$sqlquery='';
$Req_cnt = count($_REQUEST);
if($Req_cnt>0){
	switch ($_REQUEST['exporttblname']) { 
		case "RoleDetails":	    		 
			//$dispFields = array("RoleName");
			//$disporder_ID= "RoleId";						
			//$wrcon = " and (RoleName like '%".$requestData['search']['value']."%')";	
			
			$whrcon ="";
							
			$sqlquery="select * from a_roles where 1=1 and IsActive <> 2 and RoleId NOT IN(1) ";
			
			if($whrcon != "")
				$sqlquery .= $whrcon;	
		
		break;		
		default:
			echo json_encode(array("rslt"=>"2", "err_msg"=>"No tables are requested to export!!!")); 
			break;
	}
		
	if($sqlquery !='')
	{
		echo json_encode(array("rslt"=>"1","sqlquery"=>$sqlquery)); 
	}
	else{
		echo json_encode(array("rslt"=>"2", "err_msg"=>"Something went wrong on query generation, please check with support team!!!")); 
	}
}
else{
	echo json_encode(array("rslt"=>"2", "err_msg"=>"No Request parameter are there!!!")); 
}




?>





