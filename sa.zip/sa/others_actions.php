<?php 
include 'session.php';
extract($_REQUEST);

$pagename=$_REQUEST['pagename']; 

if($pagename == "modulemenusorting")
{
	$modulemenuId=$_REQUEST['modulemenuId']; 
	$sort_value=$_REQUEST['sort_value']; 
	
	$db->query("update a_modulemenus set SortingOrder='".$sort_value."' where ModuleMenuId ='".$modulemenuId."'  ");
	
	echo "success";
}

//attributemap
echo $pagename;
echo "update ecom_attributes set sortingOrder='".$sort_value."' where attrMapId ='".$attrMapId."'  ";
if($pagename == "attributemap")
{
	$attrMapId=$_REQUEST['attrMapId']; 
	$sort_value=$_REQUEST['sort_value']; 
	
	$db->query("update ecom_attributes set sortingOrder='".$sort_value."' where attrMapId ='".$attrMapId."'  ");
	
	echo "success";
}

?>