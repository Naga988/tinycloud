<?php 
require_once 'session.php';
$menudisp = "Dashboard"; 
include "includes/header.php"; 
include "includes/Mdme-functions.php";
$mdme = getMdmeMenu($db,''); 
?>  

<div class="content-part pt-1">
    <div class="container-fluid">
	
		<div class="row">
			<div class="col-md-4 toptitle">
				<h4 style="float:left;">Loreum Ipsum</h4>
			</div>
		</div>
			  
	  
    </div>
</div>

<?php include "includes/footer.php"; ?>  		
