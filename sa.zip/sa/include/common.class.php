<?php

class common{

	var $min_logout_time;
	var $root_path;
	var $http_path;
	var $prtfol_imgpath ;

	// constructor
	function common()
	{
		include "config_db.php";
		$this->min_logout_time=20*60;
		$this->path       = $path;
		$this->root_path  = $root_path;
		$this->http_path   = $http_path;
		$this->attach_rpath  = $attach_rpath;
		$this->attach_hpath   = $attach_hpath;
		$this->prtfol_imgpath = $prtfol_imgpath ;

	}

	//to generate a secure unique sessionkey
	function hashgen()
	{
		$hash = md5(uniqid(rand(),1));
		return $hash;
	}
	
	function return_file_content($db_domain,$xpath)
	{

		$fp=fopen("$xpath","r"); 
		$fullcontent=fread($fp,filesize("$xpath"));
		fclose($fp);
		return $fullcontent;
	}

	function prefix_table($tablename)
	{
		$prefix=$this->prefix;
		$tablename=$prefix.$tablename;
		return $tablename;
	}


    //checks if the site was last accessed before 20min and if so prompts user to relogin
	function check_user_session($hash,$db_domain)
  	{		
		$qry="Select user_id,timestamp from a_user_session where hash='".$hash."'";  
		$line = $db_domain->get_a_line($qry)->fetchArray();  
		$userid=$line['user_id'];
		$min_logout_time=20*60;
		$min=$min_logout_time*60;  

    	if( (time() - $line['timestamp'] ) > $min )
    	{                 
      		//echo("$session_timed_out");
      		return 0;
    	}
		else
    	{
		    $timestmp=time();
  		    $qry="Update a_user_session set timestamp='".$timestmp."' where hash='".$hash."'";
        	if (!($result = $db_domain->get_a_line($qry)))
        	{
         			$men = mysql_errno();
         			$mem = mysql_error();
         			echo ("<h4>$qry  $men $mem</h4>");
		        exit;
        	}
        	else
        	{
         			return $userid;
        	}
    	}
	}

	//===================================================





}//end class

?>