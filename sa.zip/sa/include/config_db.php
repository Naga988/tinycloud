<?php
#------ Database Details ----#
$host = "localhost";
$dbname = "tinycloud_db";
$dbuser = "root";
$dbpass = "";


//$baseurl="http://192.168.0.48/castle/caadmin";
/*
//online
$host = "localhost";
$dbname = "approio9_tinycloudtest";
$dbuser = "approio9_tinycloudtest";
$dbpass = "LHHkstDnKsfD";
*/
?> 