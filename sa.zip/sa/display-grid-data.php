<?php 
date_default_timezone_set("Asia/Kolkata"); 
include_once "session.php";
include "includes/Mdme-functions.php";

// storing  request (ie, get/post) global array to a variable  

$requestData= $_REQUEST;
include_once "display-grid-data-functions.php"; 
  
$wrcon = "";
$srchcollen = count($requestData['search']);

//print_r($requestData);

 $stt = $requestData['start'];
 $len = $requestData['length'];
  
switch ($_REQUEST['finaltab']) { 
			
	case "menu":	    		 
		$dispFields = array("MenuName");
		$disporder_ID= "MenuId";
		$mdme = getMdmeMenu($db,''); 
		
		$wrcon .= " and (MenuName like '%".$requestData['search']['value']."%')";	
						
		$order_clmn = $requestData['order'][0]['column'];
		$order_oper = $requestData['order'][0]['dir'];			
		$ordr = " order by SortingOrder $order_oper ";	
				
		$totalData = getMenuArray_tot($db,$act,$wrcon,$ordr,$stt,$len);
		$res = getMenuArray_Ajx($db,$act,$wrcon,$ordr,$stt,$len); 		
	
	break;		
		
	case "module":	    		 
		$dispFields = array("ModuleName","Description","ModulePath");
		$disporder_ID= "ModuleId";
		$mdme = getMdmeModule($db,''); 		
		
        $wrcon = " and (ModuleName like '%".$requestData['search']['value']."%' or Description like '%".$requestData['search']['value']."%' or ModulePath like '%".$requestData['search']['value']."%')";		
		
		$order_clmn = $requestData['order'][0]['column'];
		$order_oper = $requestData['order'][0]['dir'];			
		$ordr = " order by $dispFields[$order_clmn] $order_oper ";	
				
		$totalData = getModuleArray_tot($db,$act,$wrcon,$ordr,$stt,$len);
		$res = getModuleArray_Ajx($db,$act,$wrcon,$ordr,$stt,$len); 		
	
	break;
	
	case "modulemenu":	    		 
		$dispFields = array("MenuName");
		$disporder_ID= "MenuId";
		$mdme = getMdmeModulemenu($db,''); 		
		
        $wrcon = " and (MenuName like '%".$requestData['search']['value']."%')";		
				
		$order_clmn = $requestData['order'][0]['column'];
		$order_oper = $requestData['order'][0]['dir'];			
		$ordr = " order by SortingOrder $order_oper ";	
				
		$totalData = getModuleMenuArray_tot($db,$act,$wrcon,$ordr,$stt,$len);
		$res = getModuleMenuArray_Ajx($db,$act,$wrcon,$ordr,$stt,$len); 		
	
	break;
	
	case "permissioninfo":	    		 
		$dispFields = array("RoleName");
		$disporder_ID= "RoleId";
		$mdme = getMdmePermissioninfo($db,''); 		
		
        $wrcon = " and (RoleName like '%".$requestData['search']['value']."%')";		
		
		$order_clmn = $requestData['order'][0]['column'];
		$order_oper = $requestData['order'][0]['dir'];			
		$ordr = " order by $dispFields[$order_clmn] $order_oper ";	
				
		$totalData = getPermissionInfoArray_tot($db,$act,$wrcon,$ordr,$stt,$len);
		$res = getPermissionInfoArray_Ajx($db,$act,$wrcon,$ordr,$stt,$len); 		
	
	break;
	
	case "roleinfo":	    		 
		$dispFields = array("RoleName");
		$disporder_ID= "RoleId";
		$mdme = getMdmeRole($db,''); 		
		
		$wrcon = " and (RoleName like '%".$requestData['search']['value']."%')";		
		
		$order_clmn = $requestData['order'][0]['column'];
		$order_oper = $requestData['order'][0]['dir'];			
		$ordr = " order by $dispFields[$order_clmn] $order_oper ";	
				
		$totalData = getRoleArray_tot($db,$act,$wrcon,$ordr,$stt,$len);
		$res = getRoleArray_Ajx($db,$act,$wrcon,$ordr,$stt,$len); 		
	
	break;
	
	
	case "userinfo":	    		 
		$dispFields = array("user_firstname","user_lastname","user_name","user_email","RoleName");
		$disporder_ID= "user_ID";
		$mdme = getMdmeUser($db,''); 		
		
		$wrcon = " and (user_name like '%".$requestData['search']['value']."%' or user_firstname like '%".$requestData['search']['value']."%' or user_lastname like '%".$requestData['search']['value']."%' or r.RoleName like '%".$requestData['search']['value']."%')";		
		
		$order_clmn = $requestData['order'][0]['column'];
		$order_oper = $requestData['order'][0]['dir'];			
		$ordr = " order by $dispFields[$order_clmn] $order_oper ";	
				
		$totalData = getUserArray_tot($db,$act,$wrcon,$ordr,$stt,$len);
		$res = getUserArray_Ajx($db,$act,$wrcon,$ordr,$stt,$len); 		
	
	break;	
		
	default:
       echo "No-Data";
}
 
$totalFiltered = $totalData;
$data = array();

foreach($res as $r)
{
	$nestedData=array(); 			
       		
	$editid = base64_encode($r[$disporder_ID]);                    
    $stats = $r['IsActive'];					
	$actmodul = $_REQUEST['finaltab'];	
				
	if($r['IsActive'] == '1') 
	{
		//change status active to inactive		
		/*
		$incstat =  '<div class="btn-group" data-toggle="btn-toggle" >
			<button class="btn btn-default btn-sm active" type="button"><i class="fa fa-square text-green"></i> Active</button>
			<button class="btn btn-default btn-sm" type="button" onclick="funchangestatus(this,'.$statusurl.');"><i class="fa fa-square text-red"></i> &nbsp;</button></div>';	
		*/
		
		$statusurl = "'".$_REQUEST['finaltab']."_actions.php','Id=$editid&action=changestatus&actval=0'";
		$incstat='<div class="form-check form-switch">
                              <input class="form-check-input" type="checkbox" checked disabled >
                              <label class="form-check-label"></label>
                            </div>';	
														
	} else {
		//change status inactive to active
		/*			
		$incstat =  '<div class="btn-group" data-toggle="btn-toggle" >
			<button class="btn btn-default btn-sm" type="button" onclick="funchangestatus(this,'.$statusurl.');"><i class="fa fa-square text-green"></i> &nbsp;</button>
			<button class="btn btn-default btn-sm active" type="button"><i class="fa fa-square text-red"></i> InActive</button> </div>'	;
		*/
		
		$statusurl = "'".$_REQUEST['finaltab']."_actions.php','Id=$editid&action=changestatus&actval=1'";
		$incstat='<div class="form-check form-switch">
                              <input class="form-check-input" type="checkbox" disabled>
                              <label class="form-check-label"></label>
                            </div>';
	}
	
	
        
	//edit
	//$edtstat='<a href="'.$actmodul.'_form.php?act=edit&id='.$editid.'" title="edit" data-toggle="tooltip" class="btn btn-info btn-sm" ><i class="fa fa-edit"></i></a>';
	$edtstat='<span><a href="'.$actmodul.'_form.php?act=edit&id='.$editid.'" title="edit" data-toggle="tooltip"><i class="fas fa-pen"></i></a></span>';

	//del 
	$delurl = "'".$_REQUEST['finaltab']."_actions.php','Id=$editid&action=del'";
	$delstat='<a href="javascript:void(0);" title="delete" data-toggle="tooltip" class="btn btn-danger btn-sm del-btn" onClick="javascript:funStats(this,'.$delurl.')" ><i class="fa fa-times"></i></a>';	
	
	include_once "includes/pagepermission.php";
	
			  		  
	if(trim($res_modm_prm['EditPrm'])=="1") {
		$edtstat = $edtstat;
	}else{
		$edtstat = "";			
	}		  
	if(trim($res_modm_prm['DeletePrm'])=="1") {
		$delstat = $delstat;
	}else{
		$delstat = "";
	}	  
	if( trim($res_modm_prm['EditPrm'])!="1" &&  trim($res_modm_prm['DeletePrm'])!="1" ){
		$delstat = "-"; 
	}
		
	foreach ($dispFields as $dispFields_S) {
		$nestedData[] = $r[$dispFields_S];			
	}			
				
	$nestedData[] = $incstat;		 
	$nestedData[] =  $edtstat .'&nbsp;'.$delstat;
								
	$data[] = $nestedData;		
			
}
				
$json_data = array(
	"draw"            => intval( $requestData['draw'] ),   
	"recordsTotal"    => intval( $totalData ),  // total number of records
	"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
	"data"            => $data   // total data array			
);		

echo json_encode($json_data);  // send data as json format
?>