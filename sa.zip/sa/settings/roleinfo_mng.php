<?php 
require_once '../session.php';
$menudisp = "Role";
$rptname = "RoleDetails";
include APP_DIR."includes/header.php"; 
include APP_DIR."includes/Mdme-functions.php";
$mdme = getMdmeRole($db,'');
include_once APP_DIR."includes/pagepermission.php";
//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
else if(trim($res_modm_prm['ViewPrm'])=="0") {
	header("Location:".admin_public_url."error.php");
}
//check permission - END
?>  

<div class="content-part pt-1">
    <div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="custom-table-section p-3">
					<div class="row">
						<div class="col-lg-12">
							<div class="add-btn">
								<?php 
								if(trim($res_modm_prm['AddPrm'])=="1") {
								?>									
									<p> <a href="roleinfo_form.php"><i class="fas fa-plus"></i> Add Role</a> </p>
								<?php		
								}
								?>
								
							</div>
						</div>						
					</div>
					<div class="col-lg-12 col-md-12">
						<div class="searchbar">
							<div class="row">
								<div class="col-lg-3  d-flex justify-content-start align-items-center">
									<div class="file-download"> 												
										<span> <a href="javascript:;" onclick="export_options('excel','<?php echo $rptname; ?>', '')"><img src="../assets/images/xl-icon.png" alt=""></a> </span> 
										<span> <a href="javascript:;" onclick="export_options('csv', '<?php echo $rptname; ?>','')"><img src="../assets/images/csv-icon.png" alt=""></a> </span> 
										<span> <a href="javascript:;" onclick="export_options('pdf', '<?php echo $rptname; ?>','')"><img src="../assets/images/pdf-icon.png" alt=""></a> </span> 
										<span> <a href="javascript:;" onclick="export_options('print', '<?php echo $rptname; ?>','')"><img src="../assets/images/print-icon.png" alt=""></a> </span>										
									</div>
								</div>	
							</div>
						</div>
					</div>
					<div class="row mt-3" id="divToprint">
						<div class="col-lg-12">
							<div class="scrollable">
								<div class="table-scroll">
									<input type="hidden" name="disptblname" id="disptblname" value="<?php echo "roleinfo"; ?>" />
									<table class="table table-bordered table-hover" cellspacing="0" width="100%" id="tblresult">                                    
										<thead class="mb-2">
											<tr>
												<th>Role Name</th>                        
												<th>Status</th>
												<th>Actions</th>
											</tr>
										</thead>												
									</table>								
								</div>
							</div>						
						</div>
					</div>
					
				</div>
			</div>
		</div>
    </div>
 </div>
          
<?php include APP_DIR."includes/footer.php"; ?>  	

 <script>
    $(function () {       
		datatblCal(dataGridHdn);
    });
		
	function export_options1(exportExt, $acts){
		$('#frmExport').submit();
	}
  </script>	

