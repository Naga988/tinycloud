<?php 
require_once '../session.php';
$menudisp = "User";
include APP_DIR."includes/header.php"; 
include APP_DIR."includes/Mdme-functions.php"; 
$mdme = getMdmeUser($db,''); 
include_once APP_DIR."includes/pagepermission.php"; 
//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
else if(trim($res_modm_prm['ViewPrm'])=="0") {
	header("Location:".admin_public_url."error.php");
}
//check permission - END
?>  
<div class="content-part pt-1">
    <div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="custom-table-section p-3">
					<div class="row">
						<div class="col-lg-12">
							<div class="add-btn">
								<?php 
								if(trim($res_modm_prm['AddPrm'])=="1") {
								?>									
									<p> <a href="userinfo_form.php"><i class="fas fa-plus"></i> Add User</a> </p>
								<?php		
								}
								?>
								
							</div>
						</div>						
					</div>
					<div class="row mt-3">
						<div class="col-lg-12">
							<div class="scrollable">
								<div class="table-scroll">
									<input type="hidden" name="disptblname" id="disptblname" value="<?php echo "userinfo"; ?>" />
									<table class="table table-bordered table-hover" cellspacing="0" width="100%" id="tblresult">                                    
										<thead class="mb-2">
											<tr>
												<th>First Name</th>
												<th>Last Name</th>
												<th>User Name</th>						
												<th>User Email</th>
												<th>Role</th>						
												<th>Status</th>
												<th>Actions</th>
											</tr>
										</thead>												
									</table>								
								</div>
							</div>						
						</div>
					</div>
					
				</div>
			</div>
		</div>
    </div>
 </div>
          
<?php include APP_DIR."includes/footer.php"; ?>  	

 <script>
      $(function () {       
		datatblCal(dataGridHdn);
      });
  </script>	

