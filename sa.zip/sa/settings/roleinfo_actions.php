<?php 
require_once '../session.php';
extract($_REQUEST);
$act=$action;

if($chkstatus !=null)
	$status =1;
else
	$status =0;

switch($act)
{
	case 'insert':
	
	if(!empty($txtRoleName)) {
		$strChk = "select count(RoleId) as chkcnt from a_roles where RoleName = '$txtRoleName' and IsActive != '2'";
 		$reslt = $db->get_a_line($strChk)->fetchArray(); 
		if($reslt['chkcnt'] == 0) {
			
			$str="insert into a_roles(RoleName,IsActive,UserId)values('".getRealescape($db->getconn(),$txtRoleName)."','".$status."','".$_SESSION["UserId"]."')";
			$rslt = $db->query($str);			
			//$log = $db->insert_log("insert","a_roles","","Role Added Newly","role",$str);
			
			//echo json_encode(array("rslt"=>$rslt)); //success
			echo json_encode(array("rslt"=>"1")); //success
		}
		else {
			 echo json_encode(array("rslt"=>"3")); //same exists
		}
	}
	else {
		echo json_encode(array("rslt"=>"4"));  //no values
	}
	
	break;
	
	
	case 'update':	 	
	//$edit_id
	$today=date("Y-m-d");	
	if(!empty($txtRoleName)) {
		$strChk = "select count(RoleId) as chkcnt from a_roles where RoleName = '$txtRoleName' and IsActive != '2' and RoleId != '".$edit_id."' ";
 		$reslt = $db->get_a_line($strChk)->fetchArray(); 
		if($reslt[0] == 0) {
			$str = "update a_roles set RoleName = '".getRealescape($db->getconn(),$txtRoleName)."', ModifiedDate = '$today', UserId='".$_SESSION["UserId"]."'  where RoleId = '".$edit_id."'";
			$db->query($str);
			
			echo json_encode(array("rslt"=>"2"));
		}
		else {
			echo json_encode(array("rslt"=>"3")); //same exists
		}
	}
	else {
		echo json_encode(array("rslt"=>"4"));  //no values
	}
		
	break;
	
	case 'del':
	  $edit_id = base64_decode($Id);	  
	  $today = date("Y-m-d");
	  
	  $chkReference_ed = $db->get_a_line("select user_ID from a_users where RoleId = '".$edit_id."' and IsActive<>2 ")->fetchArray(); 
	  $chk_Ref_there = $chkReference_ed['user_ID'];
	  
	  if (isset($chk_Ref_there)) {
		  echo json_encode(array("rslt"=>"7")); //Reference Exists cannot delete
	  }
	  else{
		$str="update a_roles set IsActive = '2', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where RoleId = '".$edit_id."'";
		$db->query($str); 	 
	  
		//$db->insert_log("delete","a_roles",$edit_id,"Role deleted","Role",$str);
		echo json_encode(array("rslt"=>"5")); //deletion  
	  }
	  		
	break;
	
	case 'changestatus':
	  $edit_id = base64_decode($Id);
	  
	  $today = date("Y-m-d");
	  $status = $actval;
	  
	  //update role table	  
	  $str="update a_roles set IsActive = '$status', ModifiedDate = '$today' , UserId='".$_SESSION["UserId"]."'  where RoleId = '".$edit_id."'";
	  $db->query($str); 	

	  //update user table to change the status based on the role status  	 
	  $str_update_users = " update a_users set IsActive = '$status', UserId='".$_SESSION["UserId"]."' where  RoleId = '".$edit_id."' and IsActive <>2 ";
	  $db->query($str_update_users); 	
	  
	  //$db->insert_log("delete","a_roles",$edit_id,"Role status Change","Role",$str);
 	  echo json_encode(array("rslt"=>"6")); //status update success
	  	 
		
	break;
}



?>