<?php 
require_once '../session.php';
$menudisp = "User";
include APP_DIR."includes/header.php"; 
include APP_DIR."includes/Mdme-functions.php";
$mdme = getMdmeUser($db,'');
include_once APP_DIR."includes/pagepermission.php";
//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
//check permission - END

$id=$_REQUEST['id'];
if($id!="")
{
	
//check edit permission - START	
if(trim($res_modm_prm['EditPrm'])=="0") {
?>
<script>
  window.location="error.php";
</script>
<?php	
}
//check edit permission - END	

$operation="Edit";
$act="update";
$btn='Update';

$str_ed = "select * from a_users where IsActive != '2' and user_ID = '".base64_decode($id)."' ";
$res_ed = $db->get_a_line($str_ed)->fetchArray();

$edit_id = $res_ed['user_ID'];

$chk='';
if($res_ed['IsActive']=='1')
{
	$chk='checked';
}

}
else
{
	
//check edit permission - START	
if(trim($res_modm_prm['AddPrm'])=="0") {
?>
<script>
  window.location="error.php";
</script>
<?php	
}
//check edit permission - END


	$operation="Add";
	$act="insert";
	$btn='Save';
}

?>

<div class="content-part pt-5">
    <div class="container-fluid">
		<div class="row">
			<?php include APP_DIR."common/dpselect-functions.php"; ?>
			<div class="col-lg-8 col-md-12">
				<div class="nform p-3">
					<form id="jvalidate" name="frmUser" action="#" method="post">
						<input type="hidden" name="action" value="<?php echo $act; ?>" />
						<input type="hidden" name="edit_id" value="<?php echo $edit_id; ?> "  />
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">First Name <sup class="red">*</sup></label>
							<input type="text" class="form-control jsrequired" name="txtuser_firstname" id="txtuser_firstname" value="<?php echo $res_ed['user_firstname']; ?>" />
						</div>
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">Last Name <sup class="red">*</sup></label>
							<input type="text" class="form-control jsrequired" name="txtuser_lastname" id="txtuser_lastname" value="<?php echo $res_ed['user_lastname']; ?>" />
						</div>
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">Email Id as Login Id <sup class="red">*</sup></label>							
							<input type="text" class="form-control jsrequired email" name="txtuser_email" id="txtuser_email"
								<?php if ($act == 'update') { ?>
								readonly="readonly"
								<?php } ?>
								value="<?php echo $res_ed['user_email']; ?>" />
						</div>
						
						<?php
						if (($act == 'insert')) { 
						?>
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">Password <sup class="red">*</sup></label>
							<input type="password" class="form-control jsrequired" name="txtuser_pwd" id="txtuser_pwd" />
						</div>						
						<?php } ?>
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">Role <sup class="red">*</sup></label>
							<?php 
								echo getSelectBox_rolelist($db,'txtRoleId','jsrequired',$res_ed['RoleId']);
							?>
						</div>
											
						
						<!--<div class="form-group">
						  <label class="col-sm-2 control-label">Photo</label>
						  <div class="col-sm-4">					    
							<?php 
							if (!empty($res_ed['user_photo']) && ($act == 'update')) { 
							  if(file_exists(CAAROOTADMIN_DIR."/uploads/adminusers/".$res_ed['user_photo']))
							   { ?>
									   <img src="uploads/adminusers/<?php echo $res_ed['user_photo']; ?>" width="50px" align="absmiddle"/>
							   <?php
							   }
							   else{ ?>
								   <img src="uploads/NoImageAvailable.png" width="50px" align="absmiddle"/>
							   <?php }
							 } 
							 ?>							
							  <label for="exampleInputFile">File input</label>	
								<input class="product_images" id="user_photo" name="user_photo" type="file" fi-type="" >
								Allowed Extension ( jpg, png, gif )
						  </div>
						</div>	-->
						
						<div class="mb-4 d-flex">
							<label class="form-label" style="width:27%;">Status</label>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" id="chkstatus" name="chkstatus" <?php echo $chk; ?> />											
							</div>								
						</div>
						
						<?php
						if (($act == 'update')) { 
						?>
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">&nbsp;</label>
							<div class="input-group">
								<a href="javascript:void(0);" class="cpassword" id="change_pwd">Change Password</a>
							</div>
						</div>	
						<?php } ?>
						
						
						
						<div class="mb-4 d-flex justify-content-end align-items-center n-btn">						 						  
							<!--<button type="button" class="btn btn-light">Back</button>-->								
							<button class="btn btn-light" type="reset" onClick="javascript:funCancel('frmUser','jvalidate','user','userinfo_mng.php');" >Cancel</button>
							<button class="btn btn-info" type="button" onClick="javascript:funSubmtWithImg('frmUser','userinfo_actions.php','jvalidate','user','userinfo_mng.php');"><?php echo $btn; ?></button>
						</div>
					
					</form>
					
				</div>
			</div>
		</div>
    </div>
 </div>

<!-- Modal -->
<div class="position-fixed p-3" style="z-index: 11">
    <div id="mdlchange_pwd" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header mb-3 pt-3">
			<strong class="me-auto" style="padding: 1rem;">Change Password</strong>			
			<button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
			<div class="container toast-country">	
				
				<div class="row">
					<div class="row">				
						<label class="col-md-3 col-xs-12 control-label">Password</label>
						<div class="col-md-6 col-xs-12">                                            
							<div class="input-group">
								<input type="password" class="form-control " name="newpwd" id="newpwd" value=""/>
							</div>                                            
						</div>				
					</div>
					
					<div class="row p-3">				
						<label class="col-md-3 col-xs-12 control-label">Confirm Password</label>
						<div class="col-md-6 col-xs-12">                                            
							<div class="input-group">
								<input type="password" class="form-control " name="newcnfrmpwd" id="newcnfrmpwd" value=""/>
							</div>                                            
						</div>				
					</div>
								
					
				</div>  
			</div>
			<div class="mt-4 d-flex justify-content-end align-items-center n-btn">				
				<button type="button" class="btn btn-info" onclick="pwdchange();">Update</button>
			</div>
        </div>
    </div>
</div>
          
<?php include APP_DIR."includes/footer.php"; ?>  	
		  
<script type="text/javascript">       
	$(function () {       
		const toastTrigger = document.getElementById('change_pwd')
		const toastLiveExample = document.getElementById('mdlchange_pwd')
		if (toastTrigger) {
		  toastTrigger.addEventListener('click', () => {
			const toast = new bootstrap.Toast(toastLiveExample)

			toast.show()
		  })
		}
    });
 
  function pwdchange(){	
	if($('#newpwd').val() == '' || $('#newcnfrmpwd').val() == ''){
		 alert('Please Enter password and Confirm Password Details');
	}	
	else if($('#newpwd').val()!=$('#newcnfrmpwd').val()){
		 alert('Password not matches');
	}
	else{
		var user_id = $('#edit_id').val(); 
		var user_email = $('#txtuser_email').val();
		var new_pwd = $('#newpwd').val();
		$.ajax({
			url: 'userinfo_pwdchange.php',
			type: 'POST',
			data: 'user_id='+user_id+'&user_email='+user_email+'&new_pwd='+new_pwd+'',
			success: function(result) {	 														
					if(result =='success'){	
						alert("Password has been changed successfully");						
						$('#myModal').modal('hide');						
		 		    }						
					else {
                        alert(result);	
					}   
			}
		}); 				
	}
 }
 
 

 
</script> 