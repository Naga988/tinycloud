<?php 
require_once '../session.php';
extract($_REQUEST);

try{
$user_id=$_REQUEST['user_id']; 
$user_email=$_REQUEST['user_email'];
$new_pwd=$_REQUEST['new_pwd'];  

//admin user table update 	
$update=$db->query("update a_users set user_pwd='".md5($new_pwd)."' where user_ID='".$user_id."' and user_name='".$user_email."'  " );

if($update)
{
	echo "success"; //success
}
else{
	echo "error"; //same exists
}
  
}

catch (Exception $e) {
	$res = "error";
	echo "error"; //same exists
}

?>