<?php 
require_once '../session.php';
extract($_REQUEST);
$act=$action;

if($chkstatus !=null)
	$status =1;
else
	$status =0;

include 'includes/image_thumb.php';

switch($act)
{
	case 'insert':
	
	if(!empty($txtuser_email)) {
		$strChk = "select count(user_ID) from a_users where user_email = '".$txtuser_email."' and IsActive != '2'";		
 		$reslt = $db->get_a_line($strChk)->fetchArray(); 
		if($reslt[0] == 0) {		
			if(isset($_FILES["user_photo"])){
				//validate image file allowed (jpg,png,gif)
				$file_info = getimagesize($_FILES["user_photo"]['tmp_name']);
				$file_mime = explode('/',$file_info['mime']);				
				if(!in_array($file_mime[1],array('jpg','jpeg','gif','png','bmp') ) ){
					echo json_encode(array("rslt"=>"7"));
					exit();
				}
				//image upload path - starts			
				$obj=new Gthumb();			
				$path=$obj->genThumbAdminusersImage('user_photo');							
				//image upload path - ends	
			}							
			$str="insert into a_users(user_firstname, user_lastname, user_name, user_email, RoleId, IsActive, UserId, user_pwd, user_photo, createddate)values('".$txtuser_firstname."', '".$txtuser_lastname."','".$txtuser_email."', '".$txtuser_email."', '".$txtRoleId."', '".$status."', '".$_SESSION["UserId"]."', '".md5($txtuser_pwd)."', '".$path."', NOW())";
			$db->query($str);		
						
			echo json_encode(array("rslt"=>"1")); //success
		}
		else {
			 echo json_encode(array("rslt"=>"3")); //same exists
		}
	}
	else {
		echo json_encode(array("rslt"=>"4"));  //no values
	}
	
	break;
	
	
	case 'update':	 	
	//$edit_id		
	if(!empty($txtuser_email)) {
		$strChk = "select count(user_ID) from a_users where user_email ='".$txtuser_email."' and IsActive != '2' and user_ID != '".$edit_id."' ";
 		$reslt = $db->get_a_line($strChk)->fetchArray(); 
		if($reslt[0] == 0) {
			$str = "update a_users set user_firstname = '".$txtuser_firstname."', user_lastname='".$txtuser_lastname."', RoleId='".$txtRoleId."', ";
						
			if(isset($_FILES["user_photo"])){
				//validate image file allowed (jpg,png,gif)
				$file_info = getimagesize($_FILES["user_photo"]['tmp_name']);
				$file_mime = explode('/',$file_info['mime']);				
				if(!in_array($file_mime[1],array('jpg','jpeg','gif','png','bmp') ) ){
					echo json_encode(array("rslt"=>"7"));
					exit();
				}
				//image upload path - starts			
				$obj=new Gthumb();			
				$path=$obj->genThumbAdminusersImage('user_photo');	
				//image upload path - ends
				$str .= " user_photo='".$path."' , ";				
			}
			$str .= " IsActive = '".$status."', ModifiedDate = now(), UserId='".$_SESSION["UserId"]."'  where user_ID = '".$edit_id."' ";
					
								
			$db->query($str);			
			echo json_encode(array("rslt"=>"2"));
		}
		else {
			echo json_encode(array("rslt"=>"3")); //same exists
		}
	}
	else {
		echo json_encode(array("rslt"=>"4"));  //no values
	}
		
	break;
	
	case 'del':
		$edit_id = base64_decode($Id);	  
		
		$str="update a_users set IsActive =2, ModifiedDate =now(), UserId='".$_SESSION["UserId"]."'  where user_ID = '".$edit_id."'";
		$db->query($str); 	  
	 
		echo json_encode(array("rslt"=>"5")); //deletion
	break;
	
	case 'changestatus':
		$edit_id = base64_decode($Id);
	  		
		$status = $actval;
		$str="update a_users set IsActive ='".$status."', ModifiedDate =now(), UserId='".$_SESSION["UserId"]."'  where user_ID = '".$edit_id."'";
		$db->query($str); 	 
	  		
		echo json_encode(array("rslt"=>"6")); //deletion
	break;
}



?>