<?php 
require_once '../session.php';
$menudisp = "Permission Info";
include APP_DIR."includes/header.php"; 
include APP_DIR."includes/Mdme-functions.php";
$mdme = getMdmePermissioninfo($db,'');
include_once APP_DIR."includes/pagepermission.php";

//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
//check permission - END

$id=$_REQUEST['id'];
if($id!="")
{
	
//check edit permission - START	
if(trim($res_modm_prm['EditPrm'])=="0") {
?>
<script>
  window.location="error.php";
</script>
<?php	
}
//check edit permission - END	

$operation="Edit";
$act="update";
$btn='Update';

$edit_id = base64_decode($id);

$resrole_name = $db->get_a_line("select RoleName from a_roles where 1=1 and RoleId='".$edit_id."' ")->fetchArray();

//$str_ed = "select group_concat(`ModuleId`) as modulelist from a_modulemenus where 1=1 and `IsActive`=1 and `MenuId` =".$edit_id."  ";
//$res_ed = $db->get_a_line($str_ed);

//$module_listall = $res_ed['modulelist'];
//$module_listarray = explode(",",$module_listall); 

}
else
{
	
//check edit permission - START	
if(trim($res_modm_prm['AddPrm'])=="0") {
?>
<script>
  window.location="error.php";
</script>
<?php	
}
//check edit permission - END

	$operation="Add";
	$act="insert";
	$btn='Save';
}
?>  

<div class="content-part pt-5">
    <div class="container-fluid">
		<div class="row">
			<?php include APP_DIR."common/dpselect-functions.php"; ?>
			<div class="col-md-12">
				<div class="nform p-3">
					<form id="jvalidate" name="frmModuleMenu" action="#" method="post">
						<input type="hidden" name="action" value="<?php echo $act; ?>" />
						<input type="hidden" name="edit_id" value="<?php echo $edit_id; ?> "  />
						
						<div class="mb-4 d-flex justify-content-between align-items-center">
							<label class="form-label">Role Name <sup class="red">*</sup></label>							
							<input disabled id="txtRolename" class="form-control jsrequired" type="text" value="<?php echo $resrole_name['RoleName']; ?>" name="txtRolename">
						</div>
						
						<div class="mb-12 module-lists-group">
							<div class="mb-12 d-flex justify-content-between align-items-center ">
								<div class="ftitle" style="width:100%;">
								  <h4>Permission List</h4>
								</div>	
							</div>
																					
							<div class="row">
								<div class="col-md-12">
									<?php
										if($_SESSION["UserId"] =="1" || $_SESSION["UserId"]==1)	
											$mainmenu_list = $db->get_a_line("select t1.MenuId,t2.MenuName from a_modulemenus t1 inner join a_menus t2 on t1.MenuId = t2.MenuId and t2.IsActive =1 where 1=1 and t1.IsActive = 1  group by t1.MenuId")->fetchAll();
										else
											$mainmenu_list = $db->get_a_line("select t1.MenuId,t2.MenuName from a_modulemenus t1 inner join a_menus t2 on t1.MenuId = t2.MenuId and t2.IsActive =1 where 1=1 and t1.IsActive = 1 and t1.MenuId Not IN(1)  group by t1.MenuId")->fetchAll();	
										
										//Print_r($mainmenu_list); die();
										foreach($mainmenu_list as $mainmenu_list_S)
										{
									?>								  
									<div class="custom-table-section p-3">
										<div class="row">									  
											<div class="col-lg-12 col-md-12">
												<div class="searchbar">
													<div class="row">
														<div class="col-lg-3  d-flex justify-content-start align-items-center">
															<div class="file-download"> <h4 class="box-title"><?php echo $mainmenu_list_S['MenuName']; ?></h4> </div>
														</div>													
													</div>
												</div>
											</div>
										</div>
										<div class="row mt-3">
											<div class="col-lg-12">
												<div class="scrollable">
													<div class="table-scroll">
														<table class="table table-bordered table-hover" cellspacing="0" width="100%">
															<thead class="mb-2">
															<tr>
																<th width="30%">Page Name</th>
																<th width="10%"><input type="checkbox" class="iCheck-helper" id="AdPrm_<?php echo $mainmenu_list_S['MenuId']; ?>" /> Add </th>
																<th width="10%"><input type="checkbox" class="iCheck-helper" id="EdPrm_<?php echo $mainmenu_list_S['MenuId']; ?>" /> Edit</th>
																<th width="10%"><input type="checkbox" class="iCheck-helper" id="DePrm_<?php echo $mainmenu_list_S['MenuId']; ?>" /> Delete</th>
																<th width="10%"><input type="checkbox" class="iCheck-helper" id="ViPrm_<?php echo $mainmenu_list_S['MenuId']; ?>" /> View</th>
															</tr>		
															</thead>
															<tbody>
															
															<?php 
															if($_SESSION["UserId"] =="1" || $_SESSION["UserId"]==1)	
																$page_list =$db->get_a_line("select t1.*,t2.MenuName,t3.ModuleName,t3.Description,t3.ModulePath from a_modulemenus t1 
																 inner join a_menus t2 on t1.MenuId = t2.MenuId and t2.IsActive =1 
																 inner join a_modules t3 on t1.ModuleId = t3.ModuleId and t3.IsActive =1 
																 where 1=1 and  t1.IsActive =1 and t1.MenuId='".$mainmenu_list_S['MenuId']."' order by t1.moduleId asc ")->fetchAll();
															else
																$page_list =$db->get_a_line("select t1.*,t2.MenuName,t3.ModuleName,t3.Description,t3.ModulePath from a_modulemenus t1 
																 inner join a_menus t2 on t1.MenuId = t2.MenuId and t2.IsActive =1 
																 inner join a_modules t3 on t1.ModuleId = t3.ModuleId and t3.IsActive =1 
																 where 1=1 and  t1.IsActive =1 and t1.MenuId='".$mainmenu_list_S['MenuId']."' and t3.ModuleId NOT IN(1,2,3) order by t1.moduleId asc ")->fetchAll();
															 
															 foreach($page_list as $page_list_S)
															 {
															   $pagepermission_all = $db->get_a_line("select * from a_user_acl where 1=1 and IsActive =1 and RoleId='".$edit_id."' and  ModuleMenuId='".$page_list_S['ModuleMenuId']."' ")->fetchArray();									   
															 ?>	
															<tr>
																<td><?php echo $page_list_S['ModuleName']; ?></td>
																<td>
																	<div class="checkbox icheck">
																		<label>
																			<input class="AdPrm_<?php echo $mainmenu_list_S['MenuId']; ?>" type="checkbox" name="AddPrm_<?php echo $page_list_S['ModuleMenuId']; ?>" <?php if($pagepermission_all['AddPrm'] == 1 ) echo "checked"; ?>  />														
																		</label>
																	</div>
																</td>
																<td>
																	<div class="checkbox icheck">
																		<label>
																			<input class="EdPrm_<?php echo $mainmenu_list_S['MenuId']; ?>" type="checkbox" name="EditPrm_<?php echo $page_list_S['ModuleMenuId']; ?>"  <?php if($pagepermission_all['EditPrm'] == 1 ) echo "checked"; ?>  />															
																		</label>
																	</div>
																</td>
																<td>
																	<div class="checkbox icheck">
																		<label>
																			<input class="DePrm_<?php echo $mainmenu_list_S['MenuId']; ?>" type="checkbox" name="DeletePrm_<?php echo $page_list_S['ModuleMenuId']; ?>" <?php if($pagepermission_all['DeletePrm'] == 1 ) echo "checked"; ?>  />															
																		</label>
																	</div>
																</td>
																<td>
																	<div class="checkbox icheck">
																		<label>
																			<input class="ViPrm_<?php echo $mainmenu_list_S['MenuId']; ?>" type="checkbox" name="ViewPrm_<?php echo $page_list_S['ModuleMenuId']; ?>"   <?php if($pagepermission_all['ViewPrm'] == 1 ) echo "checked"; ?> />															
																		</label>
																	</div>
																</td>
										
															</tr>	

															<?php	 
															 }
															?>
															</tbody>
														</table>
													</div>
												</div>										
											</div>
										</div>
									</div>
								  
									<?php											
									}
									?>	

								</div>
							</div>						
								
						</div>
												
						
						<div class="mb-4 d-flex justify-content-end align-items-center n-btn">						 						  
							<!--<button type="button" class="btn btn-light">Back</button>-->	
							<button class="btn btn-light" type="reset" onClick="javascript:funCancel('frmPermission','jvalidate','modulemenu','permissioninfo_mng.php');" >Cancel</button>
							<button class="btn btn-info" type="button" onClick="javascript: funSubmt('frmPermission','permissioninfo_actions.php','jvalidate','permissioninfo','permissioninfo_mng.php');" ><?php echo $btn; ?></button>
						</div>
					
					</form>
					
				</div>	
			</div>
		</div>
		
    </div>
 </div>      
          
<?php include APP_DIR."includes/footer.php"; ?>  	
<script type="text/javascript">  
$(function(){
   $(".iCheck-helper").click(function () {
	    //var chkid = $(this).prev('input').attr('id');		
		var chkid = $(this).attr('id');		
		if (undefined != chkid)
		{
			if ($("#"+chkid).is(':checked')){
			  $("."+chkid).prop('checked', 'checked');
              $("."+chkid).parent('div').addClass('checked');  
			}
			else{
			  $("."+chkid).prop('checked', false);
              $("."+chkid).parent('div').removeClass('checked');  
			} 
		}	
	});
});

</script>

