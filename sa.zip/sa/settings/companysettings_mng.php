<?php 
require_once '../session.php';
$menudisp = "Organization Settings";
include APP_DIR."includes/header.php"; 
include APP_DIR."includes/Mdme-functions.php"; 
$mdme = getMdmeCompanySettings($db,''); 
include_once APP_DIR."includes/pagepermission.php"; 
//check permission - START
if(!($res_modm_prm)){
	header("Location:".admin_public_url."error.php");
}
else if(trim($res_modm_prm['ViewPrm'])=="0") {
	header("Location:".admin_public_url."error.php");
}
//check permission - END
?>  
<div class="content-part pt-1">
    <div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="custom-table-section p-3">
					<div class="row">
						<div class="col-lg-12">
							aaa
						</div>						
					</div>
					
					
				</div>
			</div>
		</div>
    </div>
 </div>
          
<?php include APP_DIR."includes/footer.php"; ?>  	